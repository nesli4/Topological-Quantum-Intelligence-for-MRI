"""
classical_baselines.py
Classical ML baselines for comparison:
  1. SVM + TDA features (RBF kernel)
  2. SVM + TDA features (polynomial kernel)
  3. Random Forest + TDA features
  4. SVM + handcrafted image features (Haralick, HOG, intensity stats)
  5. SVM + raw pixel features (PCA-reduced)
"""

import numpy as np
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
import cv2


def haralick_features(image: np.ndarray) -> np.ndarray:
    """
    Compute intensity and texture statistics.
    image: float32 [0,1] 2D array
    """
    flat = image.flatten()
    # Basic intensity stats
    basic = np.array([
        flat.mean(), flat.std(), flat.min(), flat.max(),
        np.percentile(flat, 25), np.percentile(flat, 75),
        np.percentile(flat, 10), np.percentile(flat, 90),
        float(np.sum(flat**2)),          # energy
        float(-np.sum(flat[flat>0] * np.log(flat[flat>0] + 1e-12))),  # entropy
    ], dtype=np.float32)
    
    # GLCM texture features using skimage
    try:
        from skimage.feature import grayscale_matrix_ops
        # Fallback if not available
        raise ImportError
    except ImportError:
        pass
    try:
        from skimage.feature import texture
        raise ImportError
    except ImportError:
        pass
    
    # Simple co-occurrence proxy: variance of local means
    img_rs = image.reshape(8, 8, 8, 8).mean(axis=(1, 3))  # 8x8 blocks
    block_stats = np.array([img_rs.mean(), img_rs.std(),
                             img_rs.min(), img_rs.max()], dtype=np.float32)
    return np.concatenate([basic, block_stats])


def hog_features(image: np.ndarray, target_size: int = 64) -> np.ndarray:
    """HOG features from image."""
    img_uint8 = (image * 255).astype(np.uint8)
    img_resized = cv2.resize(img_uint8, (target_size, target_size))
    
    # HOG via OpenCV
    hog = cv2.HOGDescriptor(
        _winSize=(64, 64),
        _blockSize=(16, 16),
        _blockStride=(8, 8),
        _cellSize=(8, 8),
        _nbins=9
    )
    return hog.compute(img_resized).flatten().astype(np.float32)


def intensity_histogram_features(image: np.ndarray, n_bins: int = 32) -> np.ndarray:
    """Normalised intensity histogram."""
    hist, _ = np.histogram(image, bins=n_bins, range=(0, 1))
    return (hist / (hist.sum() + 1e-12)).astype(np.float32)


def extract_classical_features(image: np.ndarray) -> np.ndarray:
    """
    Extract conventional (non-topological) image features.
    Returns concatenated feature vector.
    """
    basic = haralick_features(image)
    hist  = intensity_histogram_features(image)
    
    # Gradient features (Sobel)
    img_u8 = (image * 255).astype(np.uint8)
    gx = cv2.Sobel(img_u8, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(img_u8, cv2.CV_64F, 0, 1, ksize=3)
    grad_mag = np.sqrt(gx**2 + gy**2)
    grad_feat = np.array([grad_mag.mean(), grad_mag.std(), grad_mag.max()],
                          dtype=np.float32)
    
    return np.concatenate([basic, hist, grad_feat])


def extract_classical_batch(images: np.ndarray) -> np.ndarray:
    return np.array([extract_classical_features(img) for img in images],
                    dtype=np.float32)


def build_classical_models(n_classes: int = 4):
    """Return dict of named classical model pipelines."""
    models = {}
    
    # SVM + RBF on TDA features
    models['svm_rbf_tda'] = Pipeline([
        ('scaler', StandardScaler()),
        ('svm', SVC(kernel='rbf', C=10.0, gamma='scale',
                    probability=True, random_state=42))
    ])
    
    # SVM + Polynomial on TDA features
    models['svm_poly_tda'] = Pipeline([
        ('scaler', StandardScaler()),
        ('svm', SVC(kernel='poly', degree=3, C=5.0,
                    probability=True, random_state=42))
    ])
    
    # Random Forest on TDA features
    models['rf_tda'] = Pipeline([
        ('scaler', StandardScaler()),
        ('rf', RandomForestClassifier(n_estimators=200, max_depth=None,
                                       random_state=42, n_jobs=-1))
    ])
    
    # Gradient Boosting on TDA features
    models['gbt_tda'] = Pipeline([
        ('scaler', StandardScaler()),
        ('gbt', GradientBoostingClassifier(n_estimators=100, max_depth=4,
                                            learning_rate=0.1, random_state=42))
    ])
    
    # SVM + RBF on classical (non-TDA) features
    models['svm_rbf_classical'] = Pipeline([
        ('scaler', StandardScaler()),
        ('pca', PCA(n_components=0.95, svd_solver='full', random_state=42)),
        ('svm', SVC(kernel='rbf', C=10.0, gamma='scale',
                    probability=True, random_state=42))
    ])
    
    # Random Forest on classical features
    models['rf_classical'] = Pipeline([
        ('scaler', StandardScaler()),
        ('rf', RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1))
    ])
    
    return models


if __name__ == "__main__":
    import sys
    sys.path.insert(0, '/home/claude/tqim_research')
    from preprocessing import get_ds1_classes, build_dataset
    import zipfile
    
    names, zf = get_ds1_classes('Training')
    X, y, classes = build_dataset(zf, names, target_size=64, max_per_class=10)
    
    print(f"Images: {X.shape}")
    
    cfeat = extract_classical_features(X[0])
    print(f"Classical feature vector: {len(cfeat)} dims")
    
    cfeat_batch = extract_classical_batch(X[:5])
    print(f"Batch classical features: {cfeat_batch.shape}")
