"""
quantum_kernels.py
Quantum kernel matrices for topological MRI features.

Implements:
  - Fidelity (overlap) quantum kernel: K(x,y) = |<φ(x)|φ(y)>|²
  - Projected quantum kernel variant
  - Classical comparison kernels (RBF, polynomial)
"""

import numpy as np
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator


# ── Quantum kernel (fidelity kernel) ──────────────────────────────────────────

def fidelity_kernel_entry(sv_x: np.ndarray, sv_y: np.ndarray) -> float:
    """
    Compute fidelity (quantum kernel value) between two statevectors:
    K(x,y) = |<sv_x|sv_y>|^2
    """
    # sv_x, sv_y are complex arrays
    inner = np.dot(sv_x.conj(), sv_y)
    return float(np.abs(inner)**2)


def build_quantum_kernel_matrix(statevectors: np.ndarray) -> np.ndarray:
    """
    Build the N×N quantum kernel matrix from N statevectors.
    statevectors: (N, 2^n) complex array
    Returns: (N, N) real matrix in [0,1]
    """
    N = len(statevectors)
    K = np.zeros((N, N))
    for i in range(N):
        for j in range(i, N):
            k_val = fidelity_kernel_entry(statevectors[i], statevectors[j])
            K[i, j] = k_val
            K[j, i] = k_val
    return K


def build_quantum_kernel_matrix_from_real(features_2d: np.ndarray,
                                           n_qubits: int = 4,
                                           encoding: str = 'iqp') -> np.ndarray:
    """
    Full pipeline: real topological features → quantum states → kernel matrix.
    features_2d: (N, n_qubits) already in [0,1]
    """
    from quantum_encoding import angle_encoding_circuit, iqp_feature_map, get_statevector
    
    simulator = AerSimulator(method='statevector')
    statevectors = []
    
    for feat in features_2d:
        if encoding == 'angle':
            qc = angle_encoding_circuit(feat, n_qubits)
        else:
            qc = iqp_feature_map(feat, n_qubits, reps=1)
        sv = get_statevector(qc)
        statevectors.append(sv)
    
    statevectors = np.array(statevectors)
    return build_quantum_kernel_matrix(statevectors)


# ── Projected quantum kernel ───────────────────────────────────────────────────

def projected_quantum_kernel(sv_x: np.ndarray, sv_y: np.ndarray,
                              gamma: float = 1.0) -> float:
    """
    Projected quantum kernel: uses per-qubit local reduced density matrices.
    Γ(x) = [<Z_i>_x for i in qubits]
    K_proj(x,y) = exp(-gamma * ||Γ(x) - Γ(y)||^2)
    
    For an n-qubit state, computes expectation of Z on each qubit.
    """
    n = int(np.log2(len(sv_x)))
    
    def z_expectations(sv):
        probs = np.abs(sv)**2
        z_exp = np.zeros(n)
        for i in range(n):
            # <Z_i> = sum_b (-1)^{bit_i(b)} * |sv_b|^2
            for b in range(len(sv)):
                bit_i = (b >> (n - 1 - i)) & 1
                z_exp[i] += (1 - 2*bit_i) * probs[b]
        return z_exp
    
    gx = z_expectations(sv_x)
    gy = z_expectations(sv_y)
    return float(np.exp(-gamma * np.sum((gx - gy)**2)))


def build_projected_kernel_matrix(statevectors: np.ndarray,
                                   gamma: float = 1.0) -> np.ndarray:
    N = len(statevectors)
    K = np.zeros((N, N))
    for i in range(N):
        for j in range(i, N):
            k = projected_quantum_kernel(statevectors[i], statevectors[j], gamma)
            K[i, j] = k
            K[j, i] = k
    return K


# ── Classical comparison kernels ───────────────────────────────────────────────

def rbf_kernel(X: np.ndarray, gamma: float = None) -> np.ndarray:
    """RBF (Gaussian) kernel matrix."""
    from sklearn.metrics.pairwise import rbf_kernel as sk_rbf
    if gamma is None:
        gamma = 1.0 / X.shape[1]
    return sk_rbf(X, gamma=gamma)


def polynomial_kernel(X: np.ndarray, degree: int = 3, coef0: float = 1.0) -> np.ndarray:
    from sklearn.metrics.pairwise import polynomial_kernel as sk_poly
    return sk_poly(X, degree=degree, coef0=coef0)


# ── Kernel quality metrics ─────────────────────────────────────────────────────

def kernel_target_alignment(K: np.ndarray, y: np.ndarray) -> float:
    """
    Kernel-Target Alignment (KTA): measures how well K aligns with ideal kernel.
    KTA = <K, yy^T> / (||K||_F * ||yy^T||_F)
    Higher = better alignment with class labels.
    """
    yy = np.outer(y, y)
    numerator   = np.sum(K * yy)
    denominator = np.sqrt(np.sum(K**2)) * np.sqrt(np.sum(yy**2))
    if denominator == 0:
        return 0.0
    return float(numerator / denominator)


def effective_dimension(K: np.ndarray) -> float:
    """
    Effective dimension of the kernel matrix via eigenvalue entropy.
    Higher = more expressive feature map.
    """
    eigvals = np.linalg.eigvalsh(K)
    eigvals = np.abs(eigvals)
    eigvals = eigvals[eigvals > 1e-10]
    if len(eigvals) == 0:
        return 0.0
    p = eigvals / eigvals.sum()
    return float(np.exp(-np.sum(p * np.log(p + 1e-12))))


if __name__ == "__main__":
    import sys
    sys.path.insert(0, '/home/claude/tqim_research')
    from quantum_encoding import iqp_feature_map, get_statevector
    
    np.random.seed(42)
    N = 10
    n_qubits = 4
    features = np.random.rand(N, n_qubits)
    
    print("Building quantum kernel matrix (IQP, N=10, n=4)...")
    statevectors = []
    for feat in features:
        qc = iqp_feature_map(feat, n_qubits, reps=1)
        sv = get_statevector(qc)
        statevectors.append(sv)
    statevectors = np.array(statevectors)
    
    K_fidelity = build_quantum_kernel_matrix(statevectors)
    K_proj     = build_projected_kernel_matrix(statevectors, gamma=0.5)
    K_rbf      = rbf_kernel(features)
    
    y_binary = np.array([0,0,0,0,0,1,1,1,1,1])
    
    print(f"\nFidelity kernel diagonal: {np.diag(K_fidelity).mean():.4f}")
    print(f"Projected kernel diagonal: {np.diag(K_proj).mean():.4f}")
    
    print(f"\nKernel Target Alignment:")
    print(f"  Fidelity kernel: {kernel_target_alignment(K_fidelity, y_binary):.4f}")
    print(f"  Projected kernel: {kernel_target_alignment(K_proj, y_binary):.4f}")
    print(f"  RBF kernel: {kernel_target_alignment(K_rbf, y_binary):.4f}")
    
    print(f"\nEffective dimension:")
    print(f"  Fidelity kernel: {effective_dimension(K_fidelity):.2f}")
    print(f"  Projected kernel: {effective_dimension(K_proj):.2f}")
    print(f"  RBF kernel: {effective_dimension(K_rbf):.2f}")
