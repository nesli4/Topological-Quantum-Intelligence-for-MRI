"""
quantum_encoding.py
Quantum feature map encoding for topological MRI features.

Strategies implemented:
  A. Angle encoding (Pauli-Z rotation gates)
  B. IQP (Instantaneous Quantum Polynomial) feature map
  C. ZZFeatureMap-style two-qubit interaction map

All circuits run on Qiskit Aer statevector simulator.
"""

import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator


# ── Angle encoding ─────────────────────────────────────────────────────────────

def angle_encoding_circuit(features: np.ndarray, n_qubits: int) -> QuantumCircuit:
    """
    Encode n_qubits features via Ry rotations: Ry(π * x_i) on qubit i.
    features must be in [0,1]; we map to [0, π].
    """
    assert len(features) >= n_qubits, "Need at least n_qubits features"
    qc = QuantumCircuit(n_qubits)
    for i in range(n_qubits):
        qc.ry(np.pi * float(features[i]), i)
    return qc


# ── IQP (ZZ) feature map ───────────────────────────────────────────────────────

def iqp_feature_map(features: np.ndarray, n_qubits: int, reps: int = 1) -> QuantumCircuit:
    """
    IQP-style feature map (similar to Qiskit ZZFeatureMap).
    
    Layer: H^⊗n, then Rz(2*x_i) on each qubit,
           then CZ + Rz(2*(π-x_i)(π-x_j)) for each pair (i,j).
    Repeated reps times.
    
    This creates entanglement between features and is classically hard to simulate
    for large n (here n≤8).
    """
    qc = QuantumCircuit(n_qubits)
    x = features[:n_qubits]
    
    for _ in range(reps):
        # Hadamard layer
        for i in range(n_qubits):
            qc.h(i)
        # Single-qubit Rz
        for i in range(n_qubits):
            qc.rz(2 * float(x[i]), i)
        # Two-qubit ZZ interactions
        for i in range(n_qubits):
            for j in range(i+1, n_qubits):
                qc.cx(i, j)
                phi = 2 * (np.pi - float(x[i])) * (np.pi - float(x[j]))
                qc.rz(phi, j)
                qc.cx(i, j)
    
    return qc


# ── Statevector extraction ─────────────────────────────────────────────────────

def get_statevector(qc: QuantumCircuit) -> np.ndarray:
    """Run circuit on statevector simulator and return complex amplitude vector."""
    from qiskit import transpile
    simulator = AerSimulator(method='statevector')
    qc_sv = qc.copy()
    qc_sv.save_statevector()
    tqc = transpile(qc_sv, simulator)
    result = simulator.run(tqc).result()
    sv = np.array(result.get_statevector(tqc))
    return sv


def statevector_to_real_features(sv: np.ndarray) -> np.ndarray:
    """Convert complex statevector to real feature vector [Re, Im]."""
    return np.concatenate([sv.real, sv.imag]).astype(np.float32)


# ── Dimensionality reduction before encoding ──────────────────────────────────

def reduce_for_quantum(features: np.ndarray, n_qubits: int,
                        method: str = 'pca') -> np.ndarray:
    """
    Reduce topological feature vector to n_qubits dimensions in [0,1].
    
    method: 'pca' | 'ica' | 'select_k_best'
    """
    from sklearn.preprocessing import MinMaxScaler
    
    if features.ndim == 1:
        features = features.reshape(1, -1)
    
    # Fit on the provided features (single image — use identity for single sample)
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(features)
    
    if method == 'pca' and features.shape[0] > 1:
        from sklearn.decomposition import PCA
        pca = PCA(n_components=n_qubits)
        reduced = pca.fit_transform(scaled)
        # Rescale to [0,1]
        reduced = MinMaxScaler().fit_transform(reduced)
    else:
        # Simple: take first n_qubits components
        reduced = scaled[:, :n_qubits]
    
    return reduced.astype(np.float32)


# ── Batch quantum state generation ────────────────────────────────────────────

def encode_batch_to_statevectors(features_2d: np.ndarray,
                                   n_qubits: int = 4,
                                   encoding: str = 'iqp') -> np.ndarray:
    """
    Encode N topological feature vectors into quantum statevectors.
    
    features_2d: (N, D) already reduced to [0,1]
    Returns: (N, 2^(n_qubits+1)) real feature matrix [Re, Im]
    """
    sv_list = []
    for i, feat in enumerate(features_2d):
        if encoding == 'angle':
            qc = angle_encoding_circuit(feat, n_qubits)
        elif encoding == 'iqp':
            qc = iqp_feature_map(feat, n_qubits, reps=1)
        else:
            raise ValueError(f"Unknown encoding: {encoding}")
        
        sv = get_statevector(qc)
        sv_list.append(statevector_to_real_features(sv))
    
    return np.array(sv_list, dtype=np.float32)


if __name__ == "__main__":
    # Smoke test
    np.random.seed(42)
    feat = np.random.rand(8)  # 8 features in [0,1]
    
    print("=== Angle Encoding ===")
    qc_a = angle_encoding_circuit(feat, 4)
    sv_a = get_statevector(qc_a)
    print(f"Circuit depth: {qc_a.depth()}, Statevector dim: {len(sv_a)}")
    print(f"|sv|^2 sum: {(np.abs(sv_a)**2).sum():.6f}")
    print(qc_a.draw(output='text', fold=120))
    
    print("\n=== IQP Feature Map ===")
    qc_i = iqp_feature_map(feat, 4, reps=1)
    sv_i = get_statevector(qc_i)
    print(f"Circuit depth: {qc_i.depth()}, Statevector dim: {len(sv_i)}")
    print(f"|sv|^2 sum: {(np.abs(sv_i)**2).sum():.6f}")
