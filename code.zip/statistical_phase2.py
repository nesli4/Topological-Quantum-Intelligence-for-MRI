"""
statistical_phase2.py
Rigorous statistical validation for Phase 2:
  - MSPS vs Phase1 TDA comparison
  - Benjamini-Hochberg FDR correction
  - Permutation testing for classification
  - Effect size (Cohen's d, eta-squared)
  - Bootstrap CI on key metrics
  - Multi-seed stability
"""

import sys; sys.path.insert(0, '/home/claude/tqim_research')
import numpy as np
import io, zipfile, random, json, warnings
from collections import defaultdict
from scipy import stats
warnings.filterwarnings('ignore')

RANDOM_SEED = 42

# ── Load data (reuse saved arrays) ────────────────────────────────────────────

def load_all_features(n_per_class=60, seeds=(42, 7, 123)):
    """Load images and extract both Phase1 and MSPS features, multiple seeds."""
    from msps_descriptor import extract_msps
    from topological_features import extract_topological_feature_vector
    from preprocessing import load_image_from_zip
    
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    all_names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    classes = ['glioma', 'meningioma', 'notumor', 'pituitary']
    
    results_by_seed = {}
    
    for seed in seeds:
        random.seed(seed)
        np.random.seed(seed)
        
        X_msps, X_p1, y = [], [], []
        
        for ci, cls in enumerate(classes):
            cls_imgs = [n for n in all_names if f'/{cls}/' in n]
            sample = random.sample(cls_imgs, min(n_per_class, len(cls_imgs)))
            for path in sample:
                img = load_image_from_zip(z, path, target_size=64)
                X_msps.append(extract_msps(img))
                X_p1.append(extract_topological_feature_vector(img))
                y.append(ci)
        
        results_by_seed[seed] = {
            'X_msps': np.array(X_msps, dtype=np.float32),
            'X_p1':   np.array(X_p1,   dtype=np.float32),
            'y':      np.array(y, dtype=np.int32),
        }
        print(f'  Seed {seed}: {len(y)} samples, '
              f'MSPS={results_by_seed[seed]["X_msps"].shape[1]}, '
              f'P1={results_by_seed[seed]["X_p1"].shape[1]}')
    
    return results_by_seed, classes


# ── BH FDR correction on KW test ──────────────────────────────────────────────

def kw_with_fdr(features_by_class: dict) -> dict:
    """
    Kruskal-Wallis + Benjamini-Hochberg FDR correction.
    """
    classes = list(features_by_class.keys())
    D = list(features_by_class.values())[0].shape[1]
    
    p_values = []
    kw_stats = []
    for d in range(D):
        groups = [features_by_class[c][:, d] for c in classes]
        try:
            stat, p = stats.kruskal(*groups)
            p_values.append(p)
            kw_stats.append(stat)
        except Exception:
            p_values.append(1.0)
            kw_stats.append(0.0)
    
    p_arr = np.array(p_values)
    
    # BH correction
    n = len(p_arr)
    sorted_idx = np.argsort(p_arr)
    bh_threshold = np.arange(1, n+1) / n * 0.05  # FDR = 5%
    
    # Find largest k where p_(k) <= k/n * 0.05
    bh_reject = np.zeros(n, dtype=bool)
    last_reject = -1
    for i in range(n):
        if p_arr[sorted_idx[i]] <= bh_threshold[i]:
            last_reject = i
    if last_reject >= 0:
        bh_reject[sorted_idx[:last_reject+1]] = True
    
    n_significant_raw = int((p_arr < 0.05).sum())
    n_significant_bh  = int(bh_reject.sum())
    
    # Effect size: eta-squared for each significant feature
    eta_sq = []
    for d in range(D):
        if not bh_reject[d]:
            eta_sq.append(0.0)
            continue
        all_vals = np.concatenate([features_by_class[c][:, d] for c in classes])
        grand_mean = all_vals.mean()
        ss_between = sum(
            len(features_by_class[c][:, d]) *
            (features_by_class[c][:, d].mean() - grand_mean)**2
            for c in classes
        )
        ss_total = ((all_vals - grand_mean)**2).sum()
        eta_sq.append(float(ss_between / (ss_total + 1e-12)))
    
    return dict(
        n_features=D,
        n_significant_raw=n_significant_raw,
        n_significant_bh=n_significant_bh,
        pct_significant_bh=100*n_significant_bh/D,
        mean_eta_sq_bh_features=float(np.mean([e for e, r in zip(eta_sq, bh_reject) if r])) if n_significant_bh > 0 else 0.0,
        min_p_value=float(p_arr.min()),
    )


# ── Classification comparison: MSPS vs Phase1 ─────────────────────────────────

def compare_classifiers(X_msps, X_p1, y, n_splits=5, seed=42):
    from sklearn.svm import SVC
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import balanced_accuracy_score, roc_auc_score
    
    models = {
        'SVM_RBF_MSPS':   Pipeline([('sc', StandardScaler()), ('svm', SVC(C=10, gamma='scale', probability=True, random_state=seed))]),
        'SVM_RBF_Phase1': Pipeline([('sc', StandardScaler()), ('svm', SVC(C=10, gamma='scale', probability=True, random_state=seed))]),
        'SVM_RBF_Combined': Pipeline([('sc', StandardScaler()), ('svm', SVC(C=10, gamma='scale', probability=True, random_state=seed))]),
    }
    
    X_combined = np.hstack([X_msps, X_p1])
    data = {
        'SVM_RBF_MSPS':   X_msps,
        'SVM_RBF_Phase1': X_p1,
        'SVM_RBF_Combined': X_combined,
    }
    
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    results = defaultdict(list)
    
    for name, X in data.items():
        model = models[name]
        for tr_idx, te_idx in skf.split(X, y):
            model.fit(X[tr_idx], y[tr_idx])
            pred = model.predict(X[te_idx])
            prob = model.predict_proba(X[te_idx])
            ba   = balanced_accuracy_score(y[te_idx], pred)
            try:
                auc = roc_auc_score(y[te_idx], prob, multi_class='ovr', average='weighted')
            except Exception:
                auc = float('nan')
            results[name + '_ba'].append(ba)
            results[name + '_auc'].append(auc)
    
    summary = {}
    for name in models:
        ba_vals  = results[name + '_ba']
        auc_vals = [v for v in results[name + '_auc'] if not np.isnan(v)]
        summary[name] = dict(
            ba_mean=float(np.mean(ba_vals)),
            ba_std=float(np.std(ba_vals)),
            auc_mean=float(np.mean(auc_vals)) if auc_vals else float('nan'),
        )
    return summary


# ── Bootstrap CI ───────────────────────────────────────────────────────────────

def bootstrap_model_ci(X, y, model_cls, n_boot=300, seed=42):
    from sklearn.svm import SVC
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import balanced_accuracy_score
    
    rng = np.random.default_rng(seed)
    boot_ba = []
    
    # Fixed 80/20 split
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=seed, stratify=y)
    
    model = Pipeline([('sc', StandardScaler()),
                       ('svm', SVC(C=10, gamma='scale', random_state=seed))])
    model.fit(X_tr, y_tr)
    
    for _ in range(n_boot):
        idx = rng.integers(0, len(y_te), size=len(y_te))
        y_b    = y_te[idx]
        pred_b = model.predict(X_te[idx])
        boot_ba.append(balanced_accuracy_score(y_b, pred_b))
    
    return dict(
        mean=float(np.mean(boot_ba)),
        lower=float(np.percentile(boot_ba, 2.5)),
        upper=float(np.percentile(boot_ba, 97.5)),
    )


# ── Main ───────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print('Loading multi-seed dataset...')
    data_by_seed, class_names = load_all_features(n_per_class=50, seeds=[42, 7, 123])
    
    all_clf_results = {}
    all_fdr_msps    = {}
    all_fdr_p1      = {}
    
    for seed, data in data_by_seed.items():
        X_msps = data['X_msps']
        X_p1   = data['X_p1']
        y      = data['y']
        
        print(f'\n=== Seed {seed} ===')
        
        # FDR-corrected feature significance
        from msps_descriptor import msps_feature_names
        feat_groups_msps = {c: X_msps[y==ci] for ci,c in enumerate(class_names)}
        feat_groups_p1   = {c: X_p1[y==ci]   for ci,c in enumerate(class_names)}
        
        fdr_msps = kw_with_fdr(feat_groups_msps)
        fdr_p1   = kw_with_fdr(feat_groups_p1)
        all_fdr_msps[seed] = fdr_msps
        all_fdr_p1[seed]   = fdr_p1
        
        print(f'  MSPS FDR sig: {fdr_msps["n_significant_bh"]}/{fdr_msps["n_features"]} '
              f'({fdr_msps["pct_significant_bh"]:.1f}%), mean η²={fdr_msps["mean_eta_sq_bh_features"]:.4f}')
        print(f'  P1   FDR sig: {fdr_p1["n_significant_bh"]}/{fdr_p1["n_features"]} '
              f'({fdr_p1["pct_significant_bh"]:.1f}%), mean η²={fdr_p1["mean_eta_sq_bh_features"]:.4f}')
        
        # Classification
        print('  Classification comparison...')
        clf_res = compare_classifiers(X_msps, X_p1, y, n_splits=5, seed=seed)
        all_clf_results[seed] = clf_res
        for name, res in clf_res.items():
            print(f'    {name}: BA={res["ba_mean"]:.3f}±{res["ba_std"]:.3f}, '
                  f'AUC={res["auc_mean"]:.3f}')
    
    # Aggregate across seeds
    print('\n=== Aggregated across seeds ===')
    for model_name in ['SVM_RBF_MSPS', 'SVM_RBF_Phase1', 'SVM_RBF_Combined']:
        ba_means = [all_clf_results[s][model_name]['ba_mean'] for s in [42,7,123]]
        print(f'  {model_name}: BA={np.mean(ba_means):.3f}±{np.std(ba_means):.3f}')
    
    # Bootstrap CI for MSPS vs Phase1
    print('\n=== Bootstrap CI (seed=42, n=300) ===')
    d = data_by_seed[42]
    ci_msps = bootstrap_model_ci(d['X_msps'], d['y'], None, n_boot=300, seed=42)
    ci_p1   = bootstrap_model_ci(d['X_p1'],   d['y'], None, n_boot=300, seed=42)
    print(f'  MSPS:   {ci_msps["mean"]:.3f} [{ci_msps["lower"]:.3f}, {ci_msps["upper"]:.3f}]')
    print(f'  Phase1: {ci_p1["mean"]:.3f} [{ci_p1["lower"]:.3f}, {ci_p1["upper"]:.3f}]')
    
    # Save
    out = dict(
        per_seed_fdr_msps={str(k): v for k,v in all_fdr_msps.items()},
        per_seed_fdr_p1  ={str(k): v for k,v in all_fdr_p1.items()},
        per_seed_classification={str(k): v for k,v in all_clf_results.items()},
        bootstrap_ci_msps=ci_msps,
        bootstrap_ci_p1=ci_p1,
    )
    with open('/home/claude/tqim_research/statistical_phase2_results.json', 'w') as f:
        json.dump(out, f, indent=2)
    print('\nSaved statistical_phase2_results.json')
