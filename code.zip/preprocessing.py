"""
preprocessing.py
Image preprocessing pipeline for topological MRI analysis.
Handles loading, normalisation, denoising and resizing
while preserving topologically relevant structure.
"""

import io
import zipfile
import numpy as np
from PIL import Image
import cv2
from typing import Tuple, Optional


DS1_PATH = "/mnt/user-data/uploads/brain-tumor-mri-dataset.zip"


def load_image_from_zip(zf: zipfile.ZipFile, path: str,
                        target_size: int = 128,
                        denoise: bool = True,
                        normalize: bool = True) -> np.ndarray:
    """
    Load and preprocess one MRI image for topological analysis.
    
    Returns: float32 array of shape (target_size, target_size) in [0,1]
    """
    raw = zf.read(path)
    img = Image.open(io.BytesIO(raw)).convert('L')  # grayscale
    
    # Resize with Lanczos (preserves edges better than bilinear)
    img = img.resize((target_size, target_size), Image.LANCZOS)
    arr = np.array(img, dtype=np.float32)
    
    if denoise:
        # Gaussian blur to remove acquisition noise
        # but keep sigma small to preserve topology
        arr = cv2.GaussianBlur(arr, (3, 3), sigmaX=0.8)
    
    if normalize:
        # Min-max normalise to [0,1]
        mn, mx = arr.min(), arr.max()
        if mx > mn:
            arr = (arr - mn) / (mx - mn)
        else:
            arr = np.zeros_like(arr)
    
    return arr


def build_dataset(zf: zipfile.ZipFile,
                  names_by_class: dict,
                  target_size: int = 64,
                  max_per_class: int = 200,
                  random_seed: int = 42) -> Tuple[np.ndarray, np.ndarray, list]:
    """
    Load a balanced sample from each class.
    Returns: (X, y, class_names)
    """
    import random
    rng = random.Random(random_seed)
    
    X_list, y_list = [], []
    class_names = sorted(names_by_class.keys())
    
    for label_idx, cls in enumerate(class_names):
        paths = names_by_class[cls]
        sample = rng.sample(paths, min(max_per_class, len(paths)))
        for p in sample:
            img = load_image_from_zip(zf, p, target_size=target_size)
            X_list.append(img)
            y_list.append(label_idx)
    
    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list, dtype=np.int32)
    return X, y, class_names


def get_ds1_classes(split: str = 'Training') -> dict:
    """Return {class_name: [zip_paths]} for DS1 split."""
    from collections import defaultdict
    zf = zipfile.ZipFile(DS1_PATH)
    groups = defaultdict(list)
    for n in zf.namelist():
        if n.endswith('.jpg') and split in n:
            parts = n.split('/')
            if len(parts) >= 2:
                cls = parts[-2]
                groups[cls].append(n)
    return dict(groups), zf


if __name__ == "__main__":
    names, zf = get_ds1_classes('Training')
    for cls, paths in names.items():
        print(f"  {cls}: {len(paths)} images")
    X, y, classes = build_dataset(zf, names, target_size=64, max_per_class=50)
    print(f"Dataset shape: {X.shape}, labels: {y.shape}")
    print(f"Classes: {classes}")
    print(f"Value range: [{X.min():.3f}, {X.max():.3f}]")
