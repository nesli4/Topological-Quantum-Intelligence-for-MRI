"""
phenotype_discovery.py
Unsupervised topological phenotyping of brain MRI.

Steps:
  1. Extract MSPS features (stable subset only)
  2. UMAP embedding
  3. HDBSCAN clustering
  4. Compare discovered clusters vs tumor labels
  5. Within-class sub-clustering (glioma, meningioma)
  6. Cluster characterisation via discriminative MSPS features
  7. Alternative explanation testing (brightness/size bias)
"""

import sys; sys.path.insert(0, '/home/claude/tqim_research')
import numpy as np
import io, zipfile, random, json, warnings
from collections import Counter
from PIL import Image as PILImg
warnings.filterwarnings('ignore')

from msps_descriptor import extract_msps, msps_feature_names

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

# ── Stable feature subset (from robustness: entropy_norm features) ────────────
STABLE_FEATURE_NAMES = [n for n in msps_feature_names() if 'entropy_norm' in n]
STABLE_FEATURE_IDX   = [msps_feature_names().index(n) for n in STABLE_FEATURE_NAMES]
print(f'Stable features: {len(STABLE_FEATURE_IDX)} (all entropy_norm variants)')


def load_full_dataset(n_per_class=80):
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    classes = ['glioma', 'meningioma', 'notumor', 'pituitary']
    images, labels, meta = [], [], []
    for cls_idx, cls in enumerate(classes):
        cls_imgs = [n for n in names if f'/{cls}/' in n]
        sample = random.sample(cls_imgs, min(n_per_class, len(cls_imgs)))
        for path in sample:
            info = z.getinfo(path)
            raw  = z.read(path)
            img  = PILImg.open(io.BytesIO(raw)).convert('L')
            orig_size = img.size
            img  = np.array(img.resize((64,64), PILImg.LANCZOS),
                             dtype=np.float32) / 255.0
            images.append(img)
            labels.append(cls_idx)
            meta.append({'class': cls, 'orig_w': orig_size[0],
                          'orig_h': orig_size[1],
                          'file_size': info.file_size,
                          'mean_intensity': float(img.mean()),
                          'std_intensity':  float(img.std())})
    return np.array(images), np.array(labels), meta, classes


# ── Feature extraction ─────────────────────────────────────────────────────────

def extract_stable_msps(images: np.ndarray) -> np.ndarray:
    """Extract only stable entropy_norm features."""
    all_feats = []
    for i, img in enumerate(images):
        if i % 20 == 0:
            print(f'  Feature extraction: {i}/{len(images)}')
        fv = extract_msps(img)
        all_feats.append(fv[STABLE_FEATURE_IDX])
    return np.array(all_feats, dtype=np.float32)


# ── UMAP + HDBSCAN ────────────────────────────────────────────────────────────

def umap_embed(X: np.ndarray, n_components: int = 2) -> np.ndarray:
    try:
        import umap
        reducer = umap.UMAP(n_components=n_components, random_state=RANDOM_SEED,
                             n_neighbors=15, min_dist=0.1, metric='cosine')
    except ImportError:
        from sklearn.manifold import TSNE
        from sklearn.preprocessing import StandardScaler
        X_s = StandardScaler().fit_transform(X)
        return TSNE(n_components=n_components, random_state=RANDOM_SEED,
                    perplexity=min(30, len(X)-1)).fit_transform(X_s)
    
    from sklearn.preprocessing import StandardScaler
    X_s = StandardScaler().fit_transform(X)
    return reducer.fit_transform(X_s)


def hdbscan_cluster(X: np.ndarray, min_cluster_size: int = 10) -> np.ndarray:
    try:
        import hdbscan
        clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size,
                                      metric='euclidean',
                                      cluster_selection_method='eom')
        return clusterer.fit_predict(X)
    except ImportError:
        from sklearn.cluster import DBSCAN
        from sklearn.preprocessing import StandardScaler
        X_s = StandardScaler().fit_transform(X)
        return DBSCAN(eps=0.5, min_samples=min_cluster_size).fit_predict(X_s)


# ── Cluster analysis ───────────────────────────────────────────────────────────

def cluster_purity(cluster_labels: np.ndarray, true_labels: np.ndarray) -> float:
    """Purity = sum_k max_c |C_k ∩ T_c| / N"""
    total = 0
    for cl in set(cluster_labels):
        if cl == -1:
            continue
        mask = cluster_labels == cl
        majority = Counter(true_labels[mask]).most_common(1)[0][1]
        total += majority
    n = (cluster_labels != -1).sum()
    return total / n if n > 0 else 0.0


def adjusted_rand_score(cl_labels, true_labels):
    from sklearn.metrics import adjusted_rand_score as ari
    mask = cl_labels != -1
    if mask.sum() < 2:
        return 0.0
    return float(ari(true_labels[mask], cl_labels[mask]))


def nmi_score(cl_labels, true_labels):
    from sklearn.metrics import normalized_mutual_info_score as nmi
    mask = cl_labels != -1
    if mask.sum() < 2:
        return 0.0
    return float(nmi(true_labels[mask], cl_labels[mask]))


def characterise_clusters(X_stable: np.ndarray, cluster_labels: np.ndarray,
                           true_labels: np.ndarray, class_names: list,
                           meta: list) -> dict:
    """
    For each discovered cluster:
      - Dominant tumor class
      - Mean/std intensity (alternative explanation test)
      - Mean/std original image size
      - Most discriminative stable MSPS features
    """
    feat_names = [msps_feature_names()[i] for i in STABLE_FEATURE_IDX]
    unique_clusters = sorted([c for c in set(cluster_labels) if c != -1])
    
    cluster_info = {}
    for cl in unique_clusters:
        mask = cluster_labels == cl
        
        # Class distribution
        class_dist = Counter(class_names[true_labels[i]]
                              for i in range(len(true_labels)) if mask[i])
        
        # Image metadata
        intensities = [meta[i]['mean_intensity'] for i in range(len(meta)) if mask[i]]
        sizes       = [meta[i]['orig_w']          for i in range(len(meta)) if mask[i]]
        file_sizes  = [meta[i]['file_size']        for i in range(len(meta)) if mask[i]]
        
        # Mean feature values
        feat_means = X_stable[mask].mean(axis=0)
        
        cluster_info[int(cl)] = dict(
            n=int(mask.sum()),
            class_distribution=dict(class_dist),
            dominant_class=class_dist.most_common(1)[0][0],
            mean_intensity=float(np.mean(intensities)),
            std_intensity=float(np.std(intensities)),
            mean_orig_size=float(np.mean(sizes)),
            std_orig_size=float(np.std(sizes)),
            mean_file_size_kb=float(np.mean(file_sizes)/1024),
            top_features=dict(zip(feat_names, feat_means.tolist()))
        )
    
    return cluster_info


# ── Permutation test: are clusters better than random? ───────────────────────

def permutation_test_ari(X: np.ndarray, true_labels: np.ndarray,
                          observed_ari: float, n_permutations: int = 200) -> float:
    """
    Test H0: ARI is as good as random label assignment.
    Returns p-value.
    """
    from sklearn.metrics import adjusted_rand_score as ari
    rng = np.random.default_rng(RANDOM_SEED)
    null_aris = []
    
    for _ in range(n_permutations):
        perm_labels = rng.permutation(true_labels)
        # Random cluster assignment with same number of clusters
        n_cl = len(set(true_labels))
        rand_cl = rng.integers(0, n_cl, size=len(X))
        null_aris.append(float(ari(perm_labels, rand_cl)))
    
    p_val = float(np.mean(np.array(null_aris) >= observed_ari))
    return p_val


# ── Within-class sub-clustering ───────────────────────────────────────────────

def within_class_subclustering(X_stable: np.ndarray, labels: np.ndarray,
                                meta: list, class_names: list) -> dict:
    """
    For each class, cluster internally and test whether sub-clusters
    correspond to image quality/acquisition differences.
    """
    results = {}
    for ci, cls in enumerate(class_names):
        mask = labels == ci
        X_cls = X_stable[mask]
        meta_cls = [meta[i] for i in range(len(meta)) if mask[i]]
        
        if len(X_cls) < 20:
            continue
        
        # Embed and cluster
        emb = umap_embed(X_cls, n_components=2) if len(X_cls) >= 10 else X_cls
        sub_cl = hdbscan_cluster(emb, min_cluster_size=max(5, len(X_cls)//6))
        
        n_subclusters = len(set(sub_cl)) - (1 if -1 in sub_cl else 0)
        noise_frac    = float((sub_cl == -1).mean())
        
        # Alternative explanation: are sub-clusters explained by intensity?
        intensities = np.array([m['mean_intensity'] for m in meta_cls])
        
        # Kruskal-Wallis on intensity across sub-clusters
        from scipy.stats import kruskal
        subcluster_intensities = [intensities[sub_cl == c]
                                   for c in set(sub_cl) if c != -1
                                   and (sub_cl == c).sum() > 1]
        
        if len(subcluster_intensities) >= 2:
            try:
                stat, p_intensity = kruskal(*subcluster_intensities)
                intensity_explains = p_intensity < 0.05
            except Exception:
                p_intensity = 1.0
                intensity_explains = False
        else:
            p_intensity = 1.0
            intensity_explains = False
        
        results[cls] = dict(
            n=int(mask.sum()),
            n_subclusters=n_subclusters,
            noise_fraction=noise_frac,
            p_intensity_kw=float(p_intensity),
            intensity_explains_subclusters=bool(intensity_explains),
            sub_cluster_sizes={int(k): int(v) for k,v in Counter(int(c) for c in sub_cl if c != -1).items()}
        )
        print(f'  {cls}: {n_subclusters} sub-clusters, '
              f'intensity KW p={p_intensity:.4f} '
              f'({"intensity-driven" if intensity_explains else "not intensity-driven"})')
    
    return results


# ── Main ───────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print('Loading dataset...')
    images, labels, meta, class_names = load_full_dataset(n_per_class=60)
    print(f'Loaded {len(images)} images')
    
    print('\nExtracting MSPS stable features...')
    X_stable = extract_stable_msps(images)
    print(f'Feature matrix: {X_stable.shape}')
    
    print('\nUMAP embedding...')
    emb2d = umap_embed(X_stable, n_components=2)
    
    print('HDBSCAN clustering...')
    cluster_labels = hdbscan_cluster(emb2d, min_cluster_size=10)
    n_clusters = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)
    noise_frac = float((cluster_labels == -1).mean())
    print(f'  Discovered {n_clusters} clusters, noise={noise_frac:.2%}')
    
    # Cluster quality metrics
    purity = cluster_purity(cluster_labels, labels)
    ari    = adjusted_rand_score(cluster_labels, labels)
    nmi    = nmi_score(cluster_labels, labels)
    print(f'  Purity={purity:.4f}, ARI={ari:.4f}, NMI={nmi:.4f}')
    
    # Permutation test
    print('  Permutation test (n=200)...')
    p_perm = permutation_test_ari(emb2d, labels, ari, n_permutations=200)
    print(f'  Permutation p-value: {p_perm:.4f}')
    
    # Cluster characterisation
    cluster_info = characterise_clusters(X_stable, cluster_labels,
                                          labels, class_names, meta)
    
    print('\nCluster descriptions:')
    for cl, info in cluster_info.items():
        print(f'  Cluster {cl}: n={info["n"]}, '
              f'dominant={info["dominant_class"]}, '
              f'dist={info["class_distribution"]}, '
              f'mean_intensity={info["mean_intensity"]:.3f}')
    
    # Within-class sub-clustering
    print('\n=== Within-class sub-clustering ===')
    subcl_results = within_class_subclustering(X_stable, labels, meta, class_names)
    
    # Save all results
    out = dict(
        n_clusters=n_clusters,
        noise_fraction=noise_frac,
        purity=purity,
        adjusted_rand_index=ari,
        nmi=nmi,
        permutation_p_value=p_perm,
        cluster_info=cluster_info,
        within_class_subclustering=subcl_results,
        embedding_2d=emb2d.tolist(),
        cluster_labels=cluster_labels.tolist(),
        true_labels=labels.tolist(),
        class_names=class_names,
        stable_feature_names=STABLE_FEATURE_NAMES,
    )
    with open('/home/claude/tqim_research/phenotype_results.json', 'w') as f:
        json.dump(out, f, indent=2)
    
    # Save embedding for visualisation
    np.save('/home/claude/tqim_research/emb2d.npy', emb2d)
    np.save('/home/claude/tqim_research/cluster_labels.npy', cluster_labels)
    np.save('/home/claude/tqim_research/true_labels.npy', labels)
    np.save('/home/claude/tqim_research/X_stable.npy', X_stable)
    
    print('\nSaved phenotype_results.json')
