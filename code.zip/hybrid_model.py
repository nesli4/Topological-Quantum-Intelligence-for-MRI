"""
hybrid_model.py
Hybrid quantum-classical learning pipeline:
  Persistent Homology → Feature Reduction (PCA) → Quantum Encoding
  → Quantum Kernel SVM or Variational Quantum Classifier (VQC)

Also implements a small Variational Quantum Circuit (VQC) for binary classification.
"""

import numpy as np
import sys
sys.path.insert(0, '/home/claude/tqim_research')


# ── Variational Quantum Circuit (VQC) ─────────────────────────────────────────

def build_vqc(n_qubits: int, n_layers: int = 2) -> tuple:
    """
    Build a parameterized VQC for binary classification.
    Architecture:
      - Angle encoding layer (Ry)
      - n_layers of: Ry(θ_i) on each qubit + ring CNOT entanglement
      - Measure expectation <Z> on qubit 0 → classify
    
    Returns: (circuit_function, n_params)
    """
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    
    n_params = n_qubits * n_layers
    
    def circuit_expectation(features: np.ndarray, params: np.ndarray) -> float:
        """
        Evaluate VQC expectation value <Z_0> given input features and parameters.
        Returns float in [-1, 1].
        """
        qc = QuantumCircuit(n_qubits, 1)
        
        # Encoding layer
        for i in range(n_qubits):
            qc.ry(np.pi * float(features[i]), i)
        
        # Variational layers
        param_idx = 0
        for layer in range(n_layers):
            # Parameterized rotations
            for i in range(n_qubits):
                qc.ry(float(params[param_idx]), i)
                param_idx += 1
            # Ring CNOT entanglement
            for i in range(n_qubits):
                qc.cx(i, (i+1) % n_qubits)
        
        # Save statevector for expectation computation
        qc.save_statevector()
        
        from qiskit import transpile
        simulator = AerSimulator(method='statevector')
        tqc = transpile(qc, simulator)
        result = simulator.run(tqc).result()
        sv = np.array(result.get_statevector(tqc))
        
        # <Z_0> = sum_b (-1)^{b_0} |sv_b|^2
        probs = np.abs(sv)**2
        z0 = sum((1 - 2*((b >> (n_qubits-1)) & 1)) * probs[b]
                  for b in range(2**n_qubits))
        return float(z0)
    
    return circuit_expectation, n_params


def vqc_predict_proba(X: np.ndarray, params: np.ndarray,
                       circuit_fn) -> np.ndarray:
    """
    Predict class probabilities for array of inputs.
    Returns (N,) array of P(class=1) in [0,1].
    """
    expectations = np.array([circuit_fn(x, params) for x in X])
    # Map [-1,1] → [0,1]
    return (expectations + 1) / 2


def vqc_loss(params: np.ndarray, X: np.ndarray, y: np.ndarray,
              circuit_fn) -> float:
    """Binary cross-entropy loss for VQC."""
    proba = vqc_predict_proba(X, params, circuit_fn)
    proba = np.clip(proba, 1e-7, 1-1e-7)
    return float(-np.mean(y * np.log(proba) + (1-y) * np.log(1-proba)))


def train_vqc(X_train: np.ndarray, y_train: np.ndarray,
               n_qubits: int = 4, n_layers: int = 2,
               n_iterations: int = 50, learning_rate: float = 0.1,
               random_seed: int = 42) -> tuple:
    """
    Train VQC using parameter-shift gradient descent.
    Returns: (trained_params, loss_history)
    """
    from scipy.optimize import minimize
    
    rng = np.random.default_rng(random_seed)
    circuit_fn, n_params = build_vqc(n_qubits, n_layers)
    
    # Random initialisation
    params_init = rng.uniform(0, 2*np.pi, n_params)
    loss_history = []
    
    def objective(params):
        loss = vqc_loss(params, X_train, y_train, circuit_fn)
        loss_history.append(loss)
        return loss
    
    # Use COBYLA (gradient-free, tolerates noisy objectives)
    result = minimize(objective, params_init, method='COBYLA',
                      options={'maxiter': n_iterations, 'rhobeg': 0.5})
    
    return result.x, loss_history, circuit_fn


# ── Quantum Kernel SVM hybrid ─────────────────────────────────────────────────

class QuantumKernelSVM:
    """
    SVM with quantum kernel from topological MRI features.
    Pipeline: TDA features → PCA(n_qubits) → quantum kernel → SVM
    """
    
    def __init__(self, n_qubits: int = 4, encoding: str = 'iqp',
                  C: float = 1.0, kernel_type: str = 'fidelity'):
        self.n_qubits = n_qubits
        self.encoding = encoding
        self.C = C
        self.kernel_type = kernel_type
        self.pca = None
        self.scaler = None
        self.svm = None
        self.train_svs = None  # cached training statevectors
    
    def _get_statevectors(self, X_reduced: np.ndarray) -> np.ndarray:
        from quantum_encoding import iqp_feature_map, angle_encoding_circuit, get_statevector
        svs = []
        for feat in X_reduced:
            if self.encoding == 'iqp':
                qc = iqp_feature_map(feat, self.n_qubits, reps=1)
            else:
                qc = angle_encoding_circuit(feat, self.n_qubits)
            sv = get_statevector(qc)
            svs.append(sv)
        return np.array(svs)
    
    def _kernel_matrix(self, svs_a: np.ndarray, svs_b: np.ndarray) -> np.ndarray:
        from quantum_kernels import fidelity_kernel_entry, projected_quantum_kernel
        N, M = len(svs_a), len(svs_b)
        K = np.zeros((N, M))
        for i in range(N):
            for j in range(M):
                if self.kernel_type == 'fidelity':
                    K[i, j] = fidelity_kernel_entry(svs_a[i], svs_b[j])
                else:
                    K[i, j] = projected_quantum_kernel(svs_a[i], svs_b[j])
        return K
    
    def fit(self, X_tda: np.ndarray, y: np.ndarray):
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import MinMaxScaler
        from sklearn.svm import SVC
        
        # Reduce to n_qubits dimensions
        self.scaler = MinMaxScaler()
        X_scaled = self.scaler.fit_transform(X_tda)
        
        self.pca = PCA(n_components=self.n_qubits, random_state=42)
        X_reduced = self.pca.fit_transform(X_scaled)
        X_reduced = MinMaxScaler().fit_transform(X_reduced)
        
        # Get quantum statevectors
        print(f"  Computing training statevectors ({len(X_reduced)} samples)...")
        self.train_svs = self._get_statevectors(X_reduced)
        self._train_X_reduced = X_reduced
        
        # Build kernel matrix
        K_train = self._kernel_matrix(self.train_svs, self.train_svs)
        
        # Train SVM with precomputed kernel
        self.svm = SVC(kernel='precomputed', C=self.C, probability=True)
        self.svm.fit(K_train, y)
        return self
    
    def predict(self, X_tda: np.ndarray) -> np.ndarray:
        from sklearn.preprocessing import MinMaxScaler
        X_scaled = self.scaler.transform(X_tda)
        X_reduced = self.pca.transform(X_scaled)
        X_reduced = MinMaxScaler().fit_transform(X_reduced)
        
        test_svs = self._get_statevectors(X_reduced)
        K_test = self._kernel_matrix(test_svs, self.train_svs)
        return self.svm.predict(K_test)
    
    def predict_proba(self, X_tda: np.ndarray) -> np.ndarray:
        from sklearn.preprocessing import MinMaxScaler
        X_scaled = self.scaler.transform(X_tda)
        X_reduced = self.pca.transform(X_scaled)
        X_reduced = MinMaxScaler().fit_transform(X_reduced)
        
        test_svs = self._get_statevectors(X_reduced)
        K_test = self._kernel_matrix(test_svs, self.train_svs)
        return self.svm.predict_proba(K_test)


if __name__ == "__main__":
    np.random.seed(42)
    
    print("=== VQC smoke test ===")
    # Binary: 0 vs 1 from 2 feature dims
    X_bin = np.array([[0.1, 0.1], [0.15, 0.2], [0.9, 0.85], [0.8, 0.9]])
    y_bin = np.array([0, 0, 1, 1])
    
    params, hist, cfn = train_vqc(X_bin, y_bin, n_qubits=2, n_layers=1,
                                    n_iterations=20, random_seed=42)
    proba = vqc_predict_proba(X_bin, params, cfn)
    preds = (proba > 0.5).astype(int)
    print(f"VQC final loss: {hist[-1]:.4f}")
    print(f"VQC predictions: {preds}, true: {y_bin}")
    print(f"VQC accuracy: {(preds==y_bin).mean():.2f}")
