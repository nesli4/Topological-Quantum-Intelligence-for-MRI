# TQIM — Topological Quantum Intelligence for Brain MRI

**Paper:** Multiscale Spatial Persistence Signatures for Brain MRI  
**Dataset:** https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset

## Setup
```bash
pip install gudhi numpy scipy scikit-learn Pillow opencv-python \
            umap-learn hdbscan qiskit qiskit-aer matplotlib
```

## Usage
```bash
python dataset_audit.py          # Step 1: audit datasets
python main.py --quick           # Step 2: full pipeline (quick mode)
python msps_descriptor.py        # MSPS descriptor standalone test
python robustness_experiments.py # Robustness analysis
python phenotype_discovery.py    # Unsupervised phenotyping
python statistical_phase2.py     # Statistical validation
```

## Module overview
| File | Description |
|---|---|
| `msps_descriptor.py` | **MSPS** — 71-dim dual-filtration topological descriptor |
| `topological_features.py` | Phase 1 TDA baseline (286-dim) |
| `preprocessing.py` | Image loading and normalisation |
| `dataset_audit.py` | Byte-level dataset audit and overlap detection |
| `robustness_experiments.py` | Perturbation protocol (8 types × 4 severities) |
| `phenotype_discovery.py` | UMAP + HDBSCAN unsupervised phenotyping |
| `statistical_phase2.py` | BH-FDR correction, bootstrap CI, permutation test |
| `quantum_encoding.py` | Angle and IQP quantum feature maps (Qiskit) |
| `quantum_kernels.py` | Fidelity and projected quantum kernels |
| `hybrid_model.py` | VQC and QuantumKernelSVM |
| `classical_baselines.py` | SVM-RBF, Random Forest, classical features |
| `visualization_phase2.py` | All figures |
| `main.py` | Full pipeline orchestration |

## Citation
```
[Author names withheld for review]
Multiscale Spatial Persistence Signatures for Brain MRI. 2026.
```
