"""visualization_phase2.py — All Phase 2 figures."""

import sys; sys.path.insert(0, '/home/claude/tqim_research')
import numpy as np, json, os, warnings
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import ListedColormap
from scipy.ndimage import gaussian_filter
warnings.filterwarnings('ignore')

OUTDIR = '/home/claude/tqim_research/figures_p2'
os.makedirs(OUTDIR, exist_ok=True)
COLORS = ['#E74C3C','#3498DB','#2ECC71','#F39C12','#9B59B6','#1ABC9C']
CLASS_NAMES = ['glioma','meningioma','notumor','pituitary']

def save(fig, name):
    p = f'{OUTDIR}/{name}.png'
    fig.savefig(p, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f'  Saved: {name}.png')
    return p


# ── 1. Robustness heatmap ─────────────────────────────────────────────────────
def plot_robustness_heatmap():
    with open('/home/claude/tqim_research/robustness_results.json') as f:
        rob = json.load(f)
    
    ptype_order = ['gaussian_noise','salt_pepper','gaussian_blur','contrast',
                   'brightness','rotation','jpeg_compression','resolution']
    ptype_labels = ['Gaussian\nNoise','Salt &\nPepper','Gaussian\nBlur','Contrast',
                    'Brightness','Rotation','JPEG\nCompr.','Resolution\nDrop']
    
    data = rob['robustness_by_perturbation']
    # Build matrix: rows=perturbation, cols=strengths
    cosine_matrix = []
    strength_labels_all = []
    for ptype in ptype_order:
        row = []
        for s, vals in sorted(data[ptype].items(), key=lambda x: float(x[0])):
            row.append(vals['mean_cosine_sim'])
        cosine_matrix.append(row)
    cosine_matrix = np.array(cosine_matrix)
    
    fig, ax = plt.subplots(figsize=(10, 5))
    im = ax.imshow(cosine_matrix, cmap='RdYlGn', vmin=0.6, vmax=1.0, aspect='auto')
    plt.colorbar(im, ax=ax, label='Mean cosine similarity to original MSPS')
    ax.set_yticks(range(len(ptype_labels)))
    ax.set_yticklabels(ptype_labels, fontsize=9)
    ax.set_xticks(range(4))
    ax.set_xticklabels(['Mild','Moderate','Strong','Severe'], fontsize=9)
    ax.set_title('MSPS Robustness: Cosine Similarity Under Perturbations', fontsize=12, fontweight='bold')
    for i in range(cosine_matrix.shape[0]):
        for j in range(cosine_matrix.shape[1]):
            ax.text(j, i, f'{cosine_matrix[i,j]:.3f}', ha='center', va='center',
                    fontsize=8, color='black' if cosine_matrix[i,j] > 0.8 else 'white')
    plt.tight_layout()
    return save(fig, 'robustness_heatmap')


# ── 2. Per-feature stability bar ──────────────────────────────────────────────
def plot_feature_stability():
    with open('/home/claude/tqim_research/robustness_results.json') as f:
        rob = json.load(f)
    
    stab = rob['per_feature_stability']
    names = list(stab.keys())
    vals  = list(stab.values())
    
    # Sort and show top/bottom
    pairs = sorted(zip(vals, names))
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 10 most stable
    stable_v, stable_n = zip(*pairs[:10])
    stable_n = [n.replace('entropy_norm','ent').replace('mean_pers','mpers')
                 .replace('max_pers','Mpers').replace('n_norm','n') for n in stable_n]
    ax1.barh(range(10), stable_v, color='#2ECC71', alpha=0.85, edgecolor='k', linewidth=0.5)
    ax1.set_yticks(range(10)); ax1.set_yticklabels(stable_n, fontsize=8)
    ax1.set_xlabel('Mean relative change (lower = more stable)', fontsize=10)
    ax1.set_title('10 Most Stable MSPS Features', fontsize=11, fontweight='bold')
    ax1.grid(True, axis='x', alpha=0.3)
    
    # 10 least stable
    unstable_v, unstable_n = zip(*pairs[-10:])
    unstable_n = [n[:25] for n in unstable_n]
    ax2.barh(range(10), unstable_v, color='#E74C3C', alpha=0.85, edgecolor='k', linewidth=0.5)
    ax2.set_yticks(range(10)); ax2.set_yticklabels(unstable_n, fontsize=8)
    ax2.set_xlabel('Mean relative change', fontsize=10)
    ax2.set_title('10 Least Stable MSPS Features', fontsize=11, fontweight='bold')
    ax2.grid(True, axis='x', alpha=0.3)
    
    plt.suptitle('MSPS Per-Feature Robustness', fontsize=13, fontweight='bold')
    plt.tight_layout()
    return save(fig, 'feature_stability')


# ── 3. UMAP clustering ────────────────────────────────────────────────────────
def plot_umap_clustering():
    emb       = np.load('/home/claude/tqim_research/emb2d.npy')
    cl_labels = np.load('/home/claude/tqim_research/cluster_labels.npy')
    true_lab  = np.load('/home/claude/tqim_research/true_labels.npy')
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    for ax in [ax1, ax2]:
        ax.set_facecolor('#F8F9FA')
        ax.grid(True, alpha=0.2)
    
    # Left: UMAP coloured by true class
    for ci, cls in enumerate(CLASS_NAMES):
        mask = true_lab == ci
        ax1.scatter(emb[mask,0], emb[mask,1], c=COLORS[ci], s=25,
                    alpha=0.75, label=cls, edgecolors='none')
    ax1.set_title('UMAP of MSPS Stable Features\n(coloured by true tumor class)', 
                   fontsize=11, fontweight='bold')
    ax1.legend(fontsize=9, markerscale=1.5)
    ax1.set_xticks([]); ax1.set_yticks([])
    
    # Right: UMAP coloured by HDBSCAN cluster
    unique_cl = sorted(set(cl_labels))
    cmap = ['#95A5A6'] + COLORS  # grey for noise (-1)
    for ci, cl in enumerate(unique_cl):
        mask = cl_labels == cl
        col  = '#CCCCCC' if cl == -1 else COLORS[ci % len(COLORS)]
        lab  = 'noise' if cl == -1 else f'cluster {cl}'
        ax2.scatter(emb[mask,0], emb[mask,1], c=col, s=25,
                    alpha=0.75, label=lab, edgecolors='none')
    ax2.set_title(f'UMAP: HDBSCAN Clusters\n(4 discovered, purity=0.486, ARI=0.180)',
                   fontsize=11, fontweight='bold')
    ax2.legend(fontsize=9, markerscale=1.5)
    ax2.set_xticks([]); ax2.set_yticks([])
    
    plt.suptitle('Topological Phenotype Space (MSPS Entropy Features)', 
                  fontsize=13, fontweight='bold', y=1.01)
    plt.tight_layout()
    return save(fig, 'umap_clustering')


# ── 4. MSPS vs Phase1 classification comparison ───────────────────────────────
def plot_classification_comparison():
    with open('/home/claude/tqim_research/statistical_phase2_results.json') as f:
        res = json.load(f)
    
    models = ['SVM_RBF_MSPS','SVM_RBF_Phase1','SVM_RBF_Combined']
    model_labels = ['MSPS\n(71-dim)', 'Phase 1 TDA\n(286-dim)', 'Combined\n(357-dim)']
    seeds = ['42','7','123']
    
    ba_by_model = {m: [res['per_seed_classification'][s][m]['ba_mean'] 
                        for s in seeds] for m in models}
    
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.set_facecolor('#F8F9FA')
    ax.grid(True, axis='y', alpha=0.4, linestyle='--', zorder=0)
    
    x = np.arange(len(models))
    width = 0.25
    
    seed_colors = ['#2C3E50','#7F8C8D','#BDC3C7']
    for si, (seed, sc) in enumerate(zip(seeds, seed_colors)):
        vals = [ba_by_model[m][si] for m in models]
        bars = ax.bar(x + (si-1)*width, vals, width, label=f'seed={seed}',
                       color=sc, alpha=0.85, edgecolor='white', linewidth=0.8, zorder=3)
    
    # Aggregate mean line
    for xi, m in enumerate(models):
        mean_v = np.mean(ba_by_model[m])
        ax.hlines(mean_v, xi-1.5*width, xi+1.5*width, colors='#E74C3C',
                   linewidths=2.5, zorder=4)
        ax.text(xi, mean_v+0.01, f'μ={mean_v:.3f}', ha='center', 
                fontsize=9, color='#E74C3C', fontweight='bold')
    
    ax.set_xticks(x)
    ax.set_xticklabels(model_labels, fontsize=10)
    ax.set_ylabel('Balanced Accuracy (5-fold CV)', fontsize=11)
    ax.set_title('MSPS vs Phase 1 TDA: Classification Performance\nacross 3 random seeds', 
                  fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.set_ylim(0.5, 0.9)
    
    # Bootstrap CI annotation
    ci_msps = res['bootstrap_ci_msps']
    ci_p1   = res['bootstrap_ci_p1']
    ax.annotate(f'95% CI: [{ci_msps["lower"]:.3f}, {ci_msps["upper"]:.3f}]',
                xy=(0, ci_msps['mean']), xytext=(0.1, 0.56),
                fontsize=8, color='#2C3E50',
                arrowprops=dict(arrowstyle='->', color='grey', lw=0.8))
    
    plt.tight_layout()
    return save(fig, 'classification_comparison')


# ── 5. FDR significance comparison ───────────────────────────────────────────
def plot_fdr_comparison():
    with open('/home/claude/tqim_research/statistical_phase2_results.json') as f:
        res = json.load(f)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    
    for ax, (key, label, total) in zip(
            axes,
            [('per_seed_fdr_msps','MSPS (71 features)',71),
             ('per_seed_fdr_p1','Phase 1 TDA (286 features)',286)]):
        
        pcts = [res[key][s]['pct_significant_bh'] for s in ['42','7','123']]
        eta2 = [res[key][s]['mean_eta_sq_bh_features'] for s in ['42','7','123']]
        
        x = np.arange(3)
        b1 = ax.bar(x, pcts, color='#3498DB', alpha=0.8, label='% significant (BH FDR 5%)')
        ax2 = ax.twinx()
        ax2.plot(x, eta2, 'o-', color='#E74C3C', linewidth=2, markersize=8, label='mean η² effect size')
        
        ax.set_xticks(x)
        ax.set_xticklabels(['seed=42','seed=7','seed=123'])
        ax.set_ylabel('% Features Significant (BH corrected)', fontsize=9)
        ax2.set_ylabel('Mean η² (effect size)', fontsize=9, color='#E74C3C')
        ax.set_title(label, fontsize=11, fontweight='bold')
        ax.set_ylim(0, 100)
        ax2.set_ylim(0, 0.35)
        
        # Combined legend
        lines = b1, ax2.lines[0]
        labels_l = ['% significant', 'mean η²']
        ax.legend(lines, labels_l, fontsize=8)
    
    plt.suptitle('Statistical Significance (BH-corrected FDR) and Effect Sizes',
                  fontsize=12, fontweight='bold')
    plt.tight_layout()
    return save(fig, 'fdr_comparison')


# ── 6. Spatial persistence maps ───────────────────────────────────────────────
def plot_spatial_persistence_maps():
    """Show local H1 entropy patch map for one image of each class."""
    import sys; sys.path.insert(0, '/home/claude/tqim_research')
    from msps_descriptor import _persistence_one, _normalised_stats
    from preprocessing import load_image_from_zip
    import zipfile, random, io
    from PIL import Image as PILImg
    
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    all_names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    random.seed(42)
    
    fig, axes = plt.subplots(2, 4, figsize=(16, 8))
    
    for ci, cls in enumerate(CLASS_NAMES):
        cls_imgs = [n for n in all_names if f'/{cls}/' in n]
        path = random.choice(cls_imgs)
        img = load_image_from_zip(z, path, target_size=128, denoise=False)
        
        # Build 8x8 patch entropy map
        P = 8; H, W = img.shape
        ph, pw = H//P, W//P
        ent_map = np.zeros((P, P))
        for i in range(P):
            for j in range(P):
                patch = img[i*ph:(i+1)*ph, j*pw:(j+1)*pw]
                result = _persistence_one(patch, sublevel=True)
                st = _normalised_stats(result['h1'], patch.size)
                ent_map[i,j] = st['entropy_norm']
        
        # Row 0: original MRI
        axes[0, ci].imshow(img, cmap='gray', vmin=0, vmax=1)
        axes[0, ci].set_title(cls, fontsize=11, fontweight='bold',
                               color=COLORS[ci])
        axes[0, ci].axis('off')
        
        # Row 1: H1 entropy spatial map
        im = axes[1, ci].imshow(ent_map, cmap='hot', interpolation='bilinear',
                                  extent=[0, 128, 128, 0])
        axes[1, ci].axis('off')
        plt.colorbar(im, ax=axes[1,ci], fraction=0.04, pad=0.02,
                     label='H₁ entropy' if ci==3 else '')
    
    axes[0,0].set_ylabel('MRI image', fontsize=10, rotation=0, labelpad=55)
    axes[1,0].set_ylabel('H₁ entropy\nspatial map', fontsize=10, rotation=0, labelpad=40)
    
    plt.suptitle('Spatial Distribution of H₁ Persistence Entropy\n(Local-Global Topological Contrast)',
                  fontsize=13, fontweight='bold')
    plt.tight_layout()
    return save(fig, 'spatial_persistence_maps')


# ── 7. Cross-scale entropy evolution ─────────────────────────────────────────
def plot_cross_scale_entropy():
    """Show how normalised H1 entropy evolves across scales for each class."""
    import sys; sys.path.insert(0, '/home/claude/tqim_research')
    from msps_descriptor import SCALES_SIGMA, TARGET_SIZES, _persistence_one, _normalised_stats
    from preprocessing import load_image_from_zip
    import zipfile, random
    from PIL import Image as PILImg
    from scipy.ndimage import gaussian_filter as gf
    
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    all_names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    random.seed(42)
    
    n_per_class = 20
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    
    log_scales = [np.log(1.0/(s+1)+1) for s in SCALES_SIGMA]
    scale_labels = [f'σ={s}' for s in SCALES_SIGMA]
    
    for ax, (filtdir, sublevel) in zip(axes, [('Sublevel (dark→bright)', True),
                                                ('Superlevel (bright→dark)', False)]):
        ax.set_facecolor('#F8F9FA')
        ax.grid(True, alpha=0.3)
        
        for ci, cls in enumerate(CLASS_NAMES):
            cls_imgs = [n for n in all_names if f'/{cls}/' in n]
            sample = random.sample(cls_imgs, min(n_per_class, len(cls_imgs)))
            
            class_entropies = []
            for path in sample:
                img = load_image_from_zip(z, path, target_size=128)
                scale_ents = []
                for sigma, ts in zip(SCALES_SIGMA, TARGET_SIZES):
                    blurred = np.clip(gf(img, sigma=sigma), 0, 1) if sigma > 0 else img
                    arr_rs  = np.array(PILImg.fromarray((blurred*255).astype(np.uint8))
                                        .resize((ts,ts), PILImg.LANCZOS), dtype=np.float64)/255.0
                    result = _persistence_one(arr_rs, sublevel=sublevel)
                    st = _normalised_stats(result['h1'], ts*ts)
                    scale_ents.append(st['entropy_norm'])
                class_entropies.append(scale_ents)
            
            mean_ent = np.mean(class_entropies, axis=0)
            std_ent  = np.std(class_entropies, axis=0)
            
            ax.plot(range(4), mean_ent, 'o-', color=COLORS[ci],
                     linewidth=2.5, markersize=8, label=cls)
            ax.fill_between(range(4), mean_ent-std_ent, mean_ent+std_ent,
                             color=COLORS[ci], alpha=0.15)
        
        ax.set_xticks(range(4))
        ax.set_xticklabels(scale_labels, fontsize=10)
        ax.set_xlabel('Gaussian blur scale (coarser →)', fontsize=10)
        ax.set_ylabel('Normalised H₁ persistence entropy', fontsize=10)
        ax.set_title(f'Cross-Scale H₁ Entropy\n{filtdir}', fontsize=11, fontweight='bold')
        ax.legend(fontsize=9)
    
    plt.suptitle('MSPS: Cross-Scale Entropy Evolution (Γ slope captures this curve)',
                  fontsize=12, fontweight='bold', y=1.02)
    plt.tight_layout()
    return save(fig, 'cross_scale_entropy')


# ── 8. Mathematical summary figure ────────────────────────────────────────────
def plot_msps_math_summary():
    fig = plt.figure(figsize=(14, 6))
    ax = fig.add_subplot(111)
    ax.axis('off')
    
    text = r"""
  MULTISCALE SPATIAL PERSISTENCE SIGNATURE (MSPS) — Mathematical Summary

  Dual filtration:  Sub(t) = {x ∈ Ω : I(x) ≤ t}      (sublevel — dark regions)
                    Sup(t) = {x ∈ Ω : I(x) ≥ 1−t}     (superlevel — bright regions)

  Scale-normalised persistence entropy (removes count artefact):
            Ẽᵏ_d,σ(I) = Hₖ_d,σ(I) / log(nₖ_d,σ + 1)
       where  Hₖ_d,σ = −∑ᵢ pᵢ log pᵢ,   pᵢ = ℓᵢ / ∑ⱼ ℓⱼ

  Cross-scale entropy slope (novel — not in any single-scale descriptor):
            Γᵏ_d(I) = slope of linear regression { Ẽᵏ_d,σ ~ log(1/(σ+1)+1) }
       Γ > 0: topology becomes richer at finer scales (complex fine structure)
       Γ < 0: topology is dominated by coarse blobs (simple large regions)

  Local-global topological contrast (novel — captures spatial heterogeneity):
            Λ(I) = σ_patch / (Ẽ¹_sub,global(I) + ε)
       High Λ: H₁ complexity CONCENTRATED in specific image regions → mass effect
       Low Λ:  H₁ complexity DIFFUSE across image → homogeneous topology

  Total: 71 features  |  84.5% BH-corrected significant (FDR 5%)  |  mean η² = 0.156
  SVM-RBF BA (5-fold CV, 3 seeds): 0.717 ± 0.029  vs  Phase 1 (286-dim): 0.682 ± 0.008
"""
    ax.text(0.03, 0.95, text, transform=ax.transAxes, fontsize=10,
            verticalalignment='top', fontfamily='monospace',
            bbox=dict(boxstyle='round,pad=0.8', facecolor='#EBF5FB', 
                      edgecolor='#2980B9', linewidth=2))
    
    plt.tight_layout()
    return save(fig, 'msps_math_summary')


# ── Run all ───────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print('Generating Phase 2 figures...')
    plot_robustness_heatmap()
    plot_feature_stability()
    plot_umap_clustering()
    plot_classification_comparison()
    plot_fdr_comparison()
    plot_spatial_persistence_maps()
    plot_cross_scale_entropy()
    plot_msps_math_summary()
    print(f'\nAll figures saved to {OUTDIR}/')
