"""
robustness_experiments.py
Test MSPS descriptor stability under:
  Gaussian noise, salt-and-pepper, contrast, brightness,
  rotation, blur, compression, resolution change.

Distinguishes: mathematical invariance vs numerical stability vs artefact sensitivity.
"""

import sys; sys.path.insert(0, '/home/claude/tqim_research')
import numpy as np
from scipy.ndimage import gaussian_filter, rotate as nd_rotate
from PIL import Image as PILImg
import io, zipfile, random, json, warnings
warnings.filterwarnings('ignore')

from msps_descriptor import extract_msps, msps_feature_names
from topological_features import extract_topological_feature_vector as extract_phase1

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


# ── Load sample images ─────────────────────────────────────────────────────────

def load_sample_images(n_per_class=15):
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    classes = ['glioma', 'meningioma', 'notumor', 'pituitary']
    images, labels, label_names = [], [], []
    for cls_idx, cls in enumerate(classes):
        cls_imgs = [n for n in names if f'/{cls}/' in n]
        sample = random.sample(cls_imgs, min(n_per_class, len(cls_imgs)))
        for path in sample:
            raw = z.read(path)
            img = np.array(PILImg.open(io.BytesIO(raw)).convert('L'),
                            dtype=np.float32) / 255.0
            # Resize to 64x64 for speed
            img = np.array(PILImg.fromarray((img*255).astype(np.uint8))
                           .resize((64,64), PILImg.LANCZOS), dtype=np.float32)/255.0
            images.append(img)
            labels.append(cls_idx)
            label_names.append(cls)
    return np.array(images), np.array(labels), label_names


# ── Perturbation functions ─────────────────────────────────────────────────────

def perturb(img: np.ndarray, perturbation: str, strength: float) -> np.ndarray:
    """Apply perturbation to image. Returns perturbed image in [0,1]."""
    p = img.copy()
    
    if perturbation == 'gaussian_noise':
        noise = np.random.normal(0, strength, p.shape)
        p = np.clip(p + noise, 0, 1)
    
    elif perturbation == 'salt_pepper':
        mask = np.random.random(p.shape)
        p[mask < strength/2] = 0.0
        p[mask > 1 - strength/2] = 1.0
    
    elif perturbation == 'gaussian_blur':
        p = np.clip(gaussian_filter(p, sigma=strength), 0, 1)
    
    elif perturbation == 'contrast':
        # Multiply contrast: (p - 0.5) * factor + 0.5
        p = np.clip((p - 0.5) * (1 + strength) + 0.5, 0, 1)
    
    elif perturbation == 'brightness':
        p = np.clip(p + strength, 0, 1)
    
    elif perturbation == 'rotation':
        angle = strength  # degrees
        p = nd_rotate(p, angle, reshape=False, mode='nearest')
        p = np.clip(p, 0, 1)
    
    elif perturbation == 'jpeg_compression':
        # Simulate JPEG compression by quality = int(strength)
        quality = max(1, min(95, int(100 - strength * 100)))
        pil_img = PILImg.fromarray((p * 255).astype(np.uint8))
        buf = io.BytesIO()
        pil_img.save(buf, format='JPEG', quality=quality)
        buf.seek(0)
        p = np.array(PILImg.open(buf), dtype=np.float32) / 255.0
    
    elif perturbation == 'resolution':
        # Down-sample then up-sample
        factor = max(0.1, 1.0 - strength)
        small_sz = max(8, int(64 * factor))
        pil_img = PILImg.fromarray((p * 255).astype(np.uint8))
        small = pil_img.resize((small_sz, small_sz), PILImg.LANCZOS)
        back  = small.resize((64, 64), PILImg.LANCZOS)
        p = np.array(back, dtype=np.float32) / 255.0
    
    return p.astype(np.float32)


# ── Stability metric ───────────────────────────────────────────────────────────

def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two vectors."""
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na < 1e-10 or nb < 1e-10:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def relative_change(a: np.ndarray, b: np.ndarray) -> float:
    """Mean relative absolute change per feature."""
    denom = np.abs(a) + 1e-9
    return float(np.mean(np.abs(b - a) / denom))


# ── Run robustness experiment ─────────────────────────────────────────────────

PERTURBATIONS = {
    'gaussian_noise':   [0.02, 0.05, 0.10, 0.20],
    'salt_pepper':      [0.01, 0.03, 0.05, 0.10],
    'gaussian_blur':    [0.5,  1.0,  2.0,  4.0],
    'contrast':         [0.1,  0.3,  0.5,  1.0],
    'brightness':       [-0.2, -0.1, 0.1,  0.2],
    'rotation':         [5,    15,   30,   45],
    'jpeg_compression': [0.3,  0.5,  0.7,  0.9],
    'resolution':       [0.25, 0.5,  0.75, 0.875],
}


def run_robustness(images: np.ndarray, n_images: int = 20) -> dict:
    """
    For each perturbation type and strength, compute MSPS stability metrics.
    Uses n_images random images from the batch.
    """
    idx = np.random.choice(len(images), min(n_images, len(images)), replace=False)
    sample_imgs = images[idx]
    
    results = {}
    
    for ptype, strengths in PERTURBATIONS.items():
        results[ptype] = {}
        for strength in strengths:
            cosine_sims, rel_changes = [], []
            
            for img in sample_imgs:
                orig_msps  = extract_msps(img)
                pert_img   = perturb(img, ptype, strength)
                pert_msps  = extract_msps(pert_img)
                
                cosine_sims.append(cosine_similarity(orig_msps, pert_msps))
                rel_changes.append(relative_change(orig_msps, pert_msps))
            
            results[ptype][str(strength)] = dict(
                mean_cosine_sim = float(np.mean(cosine_sims)),
                std_cosine_sim  = float(np.std(cosine_sims)),
                mean_rel_change = float(np.mean(rel_changes)),
                std_rel_change  = float(np.std(rel_changes)),
            )
            print(f"  {ptype:20s} @{strength}: "
                  f"cosine={np.mean(cosine_sims):.4f} "
                  f"rel_Δ={np.mean(rel_changes):.4f}")
    
    return results


def per_feature_robustness(images: np.ndarray, n_images: int = 20) -> dict:
    """
    Identify which MSPS features are most/least robust.
    Returns stability score per feature under moderate perturbations.
    """
    idx = np.random.choice(len(images), min(n_images, len(images)), replace=False)
    sample_imgs = images[idx]
    feat_names = msps_feature_names()
    
    # Moderate perturbations
    moderate_perts = [
        ('gaussian_noise', 0.05),
        ('rotation', 15),
        ('contrast', 0.3),
        ('jpeg_compression', 0.5),
    ]
    
    # Collect feature-level relative changes
    per_feat_changes = {name: [] for name in feat_names}
    
    for ptype, strength in moderate_perts:
        for img in sample_imgs:
            orig = extract_msps(img)
            pert = extract_msps(perturb(img, ptype, strength))
            for i, name in enumerate(feat_names):
                rel_ch = abs(pert[i] - orig[i]) / (abs(orig[i]) + 1e-9)
                per_feat_changes[name].append(rel_ch)
    
    stability_scores = {
        name: float(np.mean(changes))
        for name, changes in per_feat_changes.items()
    }
    
    # Sort by stability (lower = more stable)
    ranked = sorted(stability_scores.items(), key=lambda x: x[1])
    
    print('\nMost stable features (lowest mean relative change):')
    for name, score in ranked[:10]:
        print(f'  {name:35s}: {score:.4f}')
    
    print('\nLeast stable features:')
    for name, score in ranked[-5:]:
        print(f'  {name:35s}: {score:.4f}')
    
    return stability_scores


if __name__ == '__main__':
    print('Loading sample images...')
    images, labels, label_names = load_sample_images(n_per_class=8)
    print(f'Loaded {len(images)} images')
    
    print('\n=== MSPS Robustness Experiment ===')
    rob_results = run_robustness(images, n_images=15)
    
    print('\n=== Per-Feature Stability ===')
    feat_stability = per_feature_robustness(images, n_images=10)
    
    # Save
    out = {
        'robustness_by_perturbation': rob_results,
        'per_feature_stability': feat_stability,
    }
    with open('/home/claude/tqim_research/robustness_results.json', 'w') as f:
        json.dump(out, f, indent=2)
    print('\nSaved robustness_results.json')
