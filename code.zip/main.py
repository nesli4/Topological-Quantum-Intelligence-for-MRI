"""
main.py
Full TQIM pipeline execution.
Runs all stages and produces consolidated results.

Usage: python main.py [--quick]
  --quick: Reduced sample size for fast testing (N=30 per class)
"""

import os, sys, json, time, warnings
import numpy as np
import zipfile

warnings.filterwarnings('ignore')
sys.path.insert(0, '/home/claude/tqim_research')

QUICK = '--quick' in sys.argv
N_PER_CLASS = 30 if QUICK else 120
N_CV_FOLDS  = 3  if QUICK else 5
N_QUBITS    = 4
IMG_SIZE    = 64
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

DS1_PATH = "/mnt/user-data/uploads/brain-tumor-mri-dataset.zip"
OUTDIR   = "/home/claude/tqim_research/figures"
os.makedirs(OUTDIR, exist_ok=True)

print("=" * 70)
print("  TOPOLOGICAL QUANTUM INTELLIGENCE FOR BRAIN MRI")
print(f"  Mode: {'QUICK' if QUICK else 'FULL'} | N={N_PER_CLASS}/class | n_qubits={N_QUBITS}")
print("=" * 70)


# ── Stage 1: Dataset Audit ────────────────────────────────────────────────────
print("\n[1/7] Running dataset audit...")
from dataset_audit import run as run_audit
audit = run_audit()
print(f"  DS1: {audit['dataset_1']['total_images']} images, 4 classes")
print(f"  DS2: {audit['dataset_2']['total_images']} images, 2 classes")
print(f"  Overlap: {audit['cross_dataset_overlap']['estimated_exact_duplicates']} exact duplicates")


# ── Stage 2: Load Data ─────────────────────────────────────────────────────────
print("\n[2/7] Loading and preprocessing images...")
from preprocessing import get_ds1_classes, build_dataset

names, zf = get_ds1_classes('Training')
X_train, y_train, class_names = build_dataset(
    zf, names, target_size=IMG_SIZE, max_per_class=N_PER_CLASS, random_seed=RANDOM_SEED)

names_te, zf_te = get_ds1_classes('Testing')
X_test, y_test, _ = build_dataset(
    zf_te, names_te, target_size=IMG_SIZE, max_per_class=N_PER_CLASS//3+10, random_seed=RANDOM_SEED)

print(f"  Train: {X_train.shape}, classes: {class_names}")
print(f"  Test:  {X_test.shape}")

# MRI grid visualisation
from visualization import plot_mri_grid
plot_mri_grid(X_train, y_train, class_names, n_per_class=4)
print("  MRI grid saved")


# ── Stage 3: Topological Feature Extraction ───────────────────────────────────
print("\n[3/7] Extracting topological features (this takes a while)...")
from topological_features import (
    extract_features_batch, compute_persistence_cubical,
    betti_curve_from_pairs, euler_characteristic_curve
)
from visualization import (
    plot_persistence_diagram, plot_betti_curves_comparison,
    plot_euler_curves_comparison
)

t0 = time.time()
X_tda_train = extract_features_batch(X_train, verbose=True)
X_tda_test  = extract_features_batch(X_test,  verbose=False)
t_tda = time.time() - t0
print(f"  TDA features: {X_tda_train.shape}, time={t_tda:.1f}s")

# Persistence diagrams per class (one example per class)
betti_by_class = {}
ec_by_class    = {}
for ci, cls in enumerate(class_names):
    cls_imgs = X_train[y_train == ci]
    if len(cls_imgs) == 0:
        continue
    img_ex = cls_imgs[0]
    result = compute_persistence_cubical(img_ex)
    plot_persistence_diagram(result['h0'], result['h1'],
                               title=f"{cls}", class_name=cls)
    # Betti curves (mean over class sample)
    n_sample = min(10, len(cls_imgs))
    class_betti_b0 = []
    class_betti_b1 = []
    thresholds = None
    for img in cls_imgs[:n_sample]:
        r = compute_persistence_cubical(img)
        bc = betti_curve_from_pairs(r['h0'], r['h1'], n_points=40)
        thresholds = bc['thresholds']
        class_betti_b0.append(bc['beta0'])
        class_betti_b1.append(bc['beta1'])
    betti_by_class[cls] = {
        'thresholds': thresholds,
        'beta0': list(np.mean(class_betti_b0, axis=0)),
        'beta1': list(np.mean(class_betti_b1, axis=0))
    }
    # Euler curves
    ec_stack = np.array([euler_characteristic_curve(img, 40)
                          for img in cls_imgs[:n_sample]])
    ec_by_class[cls] = ec_stack / (IMG_SIZE * IMG_SIZE)

plot_betti_curves_comparison(betti_by_class)
plot_euler_curves_comparison(ec_by_class)
print("  Topological visualisations saved")


# ── Stage 4: Classical Baselines ──────────────────────────────────────────────
print("\n[4/7] Training classical baselines...")
from classical_baselines import build_classical_models, extract_classical_batch
from statistical_validation import stratified_cv_evaluate, evaluate_all_metrics
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

X_classical_train = extract_classical_batch(X_train)
X_classical_test  = extract_classical_batch(X_test)
print(f"  Classical features: {X_classical_train.shape}")

classical_models = build_classical_models(n_classes=len(class_names))

# Remove models that need large data to avoid slow runs in quick mode
if QUICK:
    keep = ['svm_rbf_tda', 'rf_tda', 'svm_rbf_classical']
    classical_models = {k: v for k, v in classical_models.items() if k in keep}

cv_results = {}
test_results = {}

# Combine train+test for cross-val (use full available)
X_all_tda = np.vstack([X_tda_train, X_tda_test])
y_all     = np.concatenate([y_train, y_test])
X_all_cls = np.vstack([X_classical_train, X_classical_test])

for name, model in classical_models.items():
    print(f"  CV: {name}...")
    if 'classical' in name:
        X_cv = X_all_cls
    else:
        X_cv = X_all_tda
    cv_results[name] = stratified_cv_evaluate(model, X_cv, y_all,
                                               n_splits=N_CV_FOLDS)
    # Also train+evaluate on held-out test
    if 'classical' in name:
        model.fit(X_classical_train, y_train)
        y_pred = model.predict(X_classical_test)
        y_prob = model.predict_proba(X_classical_test)
    else:
        model.fit(X_tda_train, y_train)
        y_pred = model.predict(X_tda_test)
        y_prob = model.predict_proba(X_tda_test)
    test_results[name] = evaluate_all_metrics(y_test, y_pred, y_prob)

for name, res in cv_results.items():
    ba = res.get('balanced_accuracy', {})
    print(f"  {name}: BA={ba.get('mean',0):.3f} ± {ba.get('std',0):.3f}")


# ── Stage 5: Quantum Kernel SVM ───────────────────────────────────────────────
print(f"\n[5/7] Quantum kernel SVM (n_qubits={N_QUBITS})...")
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from quantum_encoding import iqp_feature_map, angle_encoding_circuit, get_statevector
from quantum_kernels import (build_quantum_kernel_matrix,
                              build_projected_kernel_matrix,
                              rbf_kernel, kernel_target_alignment,
                              effective_dimension)
from visualization import plot_kernel_heatmap, plot_confusion_matrix

# Use a subset for quantum computation (expensive)
N_QK = min(60, len(y_train))
idx_q = np.random.choice(len(y_train), N_QK, replace=False)
X_q   = X_tda_train[idx_q]
y_q   = y_train[idx_q]

# Reduce to n_qubits dims
scaler_q = MinMaxScaler()
X_q_scaled = scaler_q.fit_transform(X_q)
pca_q = PCA(n_components=N_QUBITS, random_state=RANDOM_SEED)
X_q_pca = pca_q.fit_transform(X_q_scaled)
X_q_pca = MinMaxScaler().fit_transform(X_q_pca)

print(f"  Encoding {N_QK} samples with IQP map (4 qubits)...")
t_q0 = time.time()
svs_iqp = []
for feat in X_q_pca:
    qc = iqp_feature_map(feat, N_QUBITS, reps=1)
    sv = get_statevector(qc)
    svs_iqp.append(sv)
svs_iqp = np.array(svs_iqp)
t_qenc = time.time() - t_q0

K_fidelity  = build_quantum_kernel_matrix(svs_iqp)
K_projected = build_projected_kernel_matrix(svs_iqp, gamma=0.5)
K_rbf       = rbf_kernel(X_q_pca)

# Binary labels for binary KTA (glioma vs notumor)
y_binary_q = (y_q == 0).astype(int)  # glioma vs rest
kta_fid  = kernel_target_alignment(K_fidelity,  y_binary_q)
kta_proj = kernel_target_alignment(K_projected, y_binary_q)
kta_rbf  = kernel_target_alignment(K_rbf,       y_binary_q)
eff_fid  = effective_dimension(K_fidelity)
eff_proj = effective_dimension(K_projected)
eff_rbf  = effective_dimension(K_rbf)

print(f"  Encoding time: {t_qenc:.1f}s ({t_qenc/N_QK:.2f}s/sample)")
print(f"  KTA — Fidelity: {kta_fid:.4f}, Projected: {kta_proj:.4f}, RBF: {kta_rbf:.4f}")
print(f"  Eff dim — Fidelity: {eff_fid:.2f}, Projected: {eff_proj:.2f}, RBF: {eff_rbf:.2f}")

# Plot kernel heatmaps
plot_kernel_heatmap(K_fidelity,  y_q, class_names, "Quantum Fidelity Kernel")
plot_kernel_heatmap(K_projected, y_q, class_names, "Projected Quantum Kernel")
plot_kernel_heatmap(K_rbf,       y_q, class_names, "Classical RBF Kernel")
print("  Kernel heatmaps saved")

# Visualise quantum circuit
from visualization import plot_quantum_circuit
qc_sample = iqp_feature_map(X_q_pca[0], N_QUBITS, reps=1)
plot_quantum_circuit(qc_sample, f"IQP Feature Map (n={N_QUBITS})")

# Quantum kernel SVM cross-val (small N due to cost)
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import balanced_accuracy_score

print("  Quantum SVM cross-val...")
qsvm_ba = []
qsvm_preds_all = []
qsvm_true_all  = []
skf_q = StratifiedKFold(n_splits=min(3, N_CV_FOLDS), shuffle=True, random_state=RANDOM_SEED)
for tr_i, te_i in skf_q.split(K_fidelity, y_q):
    K_tr = K_fidelity[np.ix_(tr_i, tr_i)]
    K_te = K_fidelity[np.ix_(te_i, tr_i)]
    svm_q = SVC(kernel='precomputed', C=1.0, probability=True)
    svm_q.fit(K_tr, y_q[tr_i])
    pred = svm_q.predict(K_te)
    qsvm_ba.append(balanced_accuracy_score(y_q[te_i], pred))
    qsvm_preds_all.extend(pred)
    qsvm_true_all.extend(y_q[te_i])

qsvm_mean_ba = float(np.mean(qsvm_ba))
qsvm_std_ba  = float(np.std(qsvm_ba))
print(f"  Quantum kernel SVM BA: {qsvm_mean_ba:.3f} ± {qsvm_std_ba:.3f}")

# Add to cv_results
cv_results['qsvm_fidelity'] = {
    'balanced_accuracy': {'mean': qsvm_mean_ba, 'std': qsvm_std_ba, 'values': qsvm_ba}
}

# Confusion matrix for quantum SVM
from sklearn.metrics import confusion_matrix
cm_q = confusion_matrix(qsvm_true_all, qsvm_preds_all)
plot_confusion_matrix(cm_q, class_names, "Quantum Kernel SVM")


# ── Stage 6: VQC (binary: glioma vs notumor) ─────────────────────────────────
print("\n[6/7] Variational Quantum Circuit (binary: glioma vs notumor)...")
from hybrid_model import train_vqc, vqc_predict_proba

# Binary subset
mask_binary = np.isin(y_train, [0, 2])  # glioma=0, notumor=2
X_vqc = X_q_pca[:40]  # small subset
y_vqc_bin = (y_q == 2).astype(int)[:40]  # notumor=1

n_vqc_iter = 30 if QUICK else 60
params_vqc, hist_vqc, cfn_vqc = train_vqc(
    X_vqc, y_vqc_bin, n_qubits=N_QUBITS,
    n_layers=2, n_iterations=n_vqc_iter, random_seed=RANDOM_SEED)

proba_vqc = vqc_predict_proba(X_vqc, params_vqc, cfn_vqc)
pred_vqc  = (proba_vqc > 0.5).astype(int)
vqc_acc   = float((pred_vqc == y_vqc_bin).mean())
print(f"  VQC training accuracy (binary): {vqc_acc:.3f}")
print(f"  VQC final loss: {hist_vqc[-1]:.4f}")

# Loss curve
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(7, 4))
ax.plot(hist_vqc, '#E74C3C', linewidth=2)
ax.set_xlabel('Iteration', fontsize=11)
ax.set_ylabel('Binary cross-entropy loss', fontsize=11)
ax.set_title('VQC Training Loss', fontsize=12, fontweight='bold')
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(OUTDIR, 'vqc_loss_curve.png'), dpi=150, bbox_inches='tight')
plt.close(fig)


# ── Stage 7: Statistical Analysis & KW Test ───────────────────────────────────
print("\n[7/7] Statistical analysis...")
from statistical_validation import (
    kruskal_wallis_topology_test, mcnemar_test, bootstrap_ci
)
from visualization import plot_feature_comparison_bars, plot_tda_umap

# Kruskal-Wallis on topological features
features_by_class = {
    cls: X_tda_train[y_train == ci]
    for ci, cls in enumerate(class_names)
    if (y_train == ci).sum() > 0
}
kw_result = kruskal_wallis_topology_test(features_by_class)
print(f"  KW test: {kw_result['n_significant_alpha_0_05']} / "
      f"{kw_result['n_features_tested']} features significant (α=0.05)")
print(f"  Min p-value: {kw_result['min_p_value']:.6f}")
print(f"  Fraction significant: {kw_result['pct_significant']:.1f}%")

# McNemar: RBF SVM vs RF (if both available)
if 'svm_rbf_tda' in test_results and 'rf_tda' in test_results:
    # Get held-out predictions (re-predict)
    svm_rbf = classical_models['svm_rbf_tda']
    rf      = classical_models['rf_tda']
    svm_rbf.fit(X_tda_train, y_train)
    rf.fit(X_tda_train, y_train)
    preds_svm = svm_rbf.predict(X_tda_test)
    preds_rf  = rf.predict(X_tda_test)
    mc = mcnemar_test(preds_svm, preds_rf, y_test)
    print(f"  McNemar SVM-RBF vs RF: {mc['interpretation']}")
else:
    mc = {}

# Bootstrap CI for best classical model
best_model_name = max(
    [n for n in test_results if 'tda' in n],
    key=lambda n: test_results[n].get('balanced_accuracy', 0)
)
best_model = classical_models.get(best_model_name)
if best_model:
    best_model.fit(X_tda_train, y_train)
    preds_best = best_model.predict(X_tda_test)
    boot_ci = bootstrap_ci(preds_best, y_test, n_bootstrap=500)
    print(f"  Bootstrap CI for {best_model_name}:")
    print(f"    Accuracy: {boot_ci['accuracy']['mean']:.3f} "
          f"[{boot_ci['accuracy']['lower']:.3f}, {boot_ci['accuracy']['upper']:.3f}]")

# t-SNE / UMAP embedding of TDA features
plot_tda_umap(X_tda_train, y_train, class_names,
               title="TDA Features t-SNE Projection")
print("  t-SNE plot saved")

# Final comparison bar chart
plot_feature_comparison_bars(cv_results, metric='balanced_accuracy',
                               title='Balanced Accuracy by Model')
print("  Model comparison bar chart saved")


# ── Consolidated Results ──────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("RESULTS SUMMARY")
print("=" * 70)

print("\nClassical models (5-fold CV, balanced accuracy):")
for name, res in cv_results.items():
    ba = res.get('balanced_accuracy', {})
    print(f"  {name:30s}: {ba.get('mean', 0):.3f} ± {ba.get('std', 0):.3f}")

print(f"\nQuantum kernel SVM (fidelity, {N_QUBITS} qubits):")
print(f"  Balanced accuracy: {qsvm_mean_ba:.3f} ± {qsvm_std_ba:.3f}")

print(f"\nVQC (binary, glioma vs notumor):")
print(f"  Training accuracy: {vqc_acc:.3f}")

print(f"\nTopological feature significance (KW test):")
print(f"  Significant features: {kw_result['n_significant_alpha_0_05']}"
      f"/{kw_result['n_features_tested']} ({kw_result['pct_significant']:.1f}%)")
print(f"  Min p-value: {kw_result['min_p_value']:.2e}")

print(f"\nKernel Target Alignment (glioma vs rest):")
print(f"  IQP fidelity kernel: {kta_fid:.4f}")
print(f"  Projected quantum:   {kta_proj:.4f}")
print(f"  Classical RBF:       {kta_rbf:.4f}")

print(f"\nFigures saved to: {OUTDIR}")
print(f"Audit report:     /home/claude/tqim_research/audit_report.json")

# Save full results
final_results = {
    'cv_results': cv_results,
    'test_results': test_results,
    'quantum_kernel': {
        'kta_fidelity': kta_fid,
        'kta_projected': kta_proj,
        'kta_rbf': kta_rbf,
        'eff_dim_fidelity': eff_fid,
        'eff_dim_projected': eff_proj,
        'eff_dim_rbf': eff_rbf,
        'cv_balanced_accuracy_mean': qsvm_mean_ba,
        'cv_balanced_accuracy_std': qsvm_std_ba,
        'encoding_time_per_sample': t_qenc / N_QK,
    },
    'vqc': {
        'training_accuracy': vqc_acc,
        'final_loss': float(hist_vqc[-1]) if hist_vqc else None,
    },
    'topological_significance': kw_result,
    'mcnemar': mc,
}

import json
with open('/home/claude/tqim_research/results.json', 'w') as f:
    json.dump(final_results, f, indent=2, default=str)
print("\nFull results saved to /home/claude/tqim_research/results.json")
print("\nPipeline complete.")
