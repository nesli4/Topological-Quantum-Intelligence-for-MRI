"""
topological_features.py
Topological feature extraction pipeline using:
- Cubical complexes (GUDHI)
- Persistent homology (H0, H1)
- Persistence landscapes
- Betti curves
- Euler characteristic curves
- Multi-threshold topology
"""

import numpy as np
import gudhi
from gudhi.representations import Landscape, BettiCurve
import warnings
warnings.filterwarnings('ignore')


# ── Cubical complex persistence ────────────────────────────────────────────────

def compute_persistence_cubical(image: np.ndarray) -> dict:
    """
    Compute persistent homology of a 2D grayscale image using cubical complexes.
    
    image: float array in [0,1], shape (H, W)
    Returns dict of raw persistence pairs and derived statistics.
    """
    H, W = image.shape
    
    # GUDHI CubicalComplex: top_dimensional_cells = pixel values
    # Sublevel filtration: connects pixels from dark to bright
    cc = gudhi.CubicalComplex(
        dimensions=[H, W],
        top_dimensional_cells=image.flatten()
    )
    cc.compute_persistence()
    pairs = cc.persistence()
    
    h0 = [(b, d) for (dim, (b, d)) in pairs if dim == 0 and d != float('inf')]
    h1 = [(b, d) for (dim, (b, d)) in pairs if dim == 1 and d != float('inf')]
    betti = cc.betti_numbers()
    
    return dict(h0=h0, h1=h1, betti=betti, raw_pairs=pairs)


def persistence_statistics(pairs: list) -> dict:
    """Derive scalar statistics from a list of (birth, death) pairs."""
    if not pairs:
        return dict(count=0, mean_persistence=0, std_persistence=0,
                    max_persistence=0, sum_persistence=0,
                    mean_birth=0, mean_death=0, entropy=0)
    lifetimes = np.array([d - b for b, d in pairs])
    births    = np.array([b for b, d in pairs])
    deaths    = np.array([d for b, d in pairs])
    
    # Persistent entropy
    if lifetimes.sum() > 0:
        p = lifetimes / lifetimes.sum()
        entropy = -np.sum(p * np.log(p + 1e-12))
    else:
        entropy = 0.0
    
    return dict(
        count=len(pairs),
        mean_persistence=float(lifetimes.mean()),
        std_persistence=float(lifetimes.std()),
        max_persistence=float(lifetimes.max()),
        sum_persistence=float(lifetimes.sum()),
        mean_birth=float(births.mean()),
        mean_death=float(deaths.mean()),
        entropy=float(entropy),
    )


# ── Euler characteristic curve ─────────────────────────────────────────────────

def euler_characteristic_curve(image: np.ndarray, n_thresholds: int = 50) -> np.ndarray:
    """
    Compute Euler characteristic χ(t) = V - E + F at each threshold t.
    Uses superlevel sets (pixels above threshold).
    
    Returns: array of shape (n_thresholds,)
    """
    thresholds = np.linspace(0, 1, n_thresholds)
    ec_curve = np.zeros(n_thresholds)
    
    for i, t in enumerate(thresholds):
        binary = (image >= t).astype(np.uint8)
        V = int(binary.sum())                        # vertices (pixels on)
        # 4-connected edges (horizontal + vertical between adjacent ON pixels)
        E_h = int((binary[:, :-1] * binary[:, 1:]).sum())
        E_v = int((binary[:-1, :] * binary[1:, :]).sum())
        E = E_h + E_v
        # 2-cell (squares): all four corners ON
        F = int((binary[:-1, :-1] * binary[:-1, 1:] *
                 binary[1:, :-1]  * binary[1:, 1:]).sum())
        ec_curve[i] = V - E + F
    
    return ec_curve


# ── Betti curve ─────────────────────────────────────────────────────────────────

def betti_curve_from_pairs(pairs_h0: list, pairs_h1: list,
                            n_points: int = 50) -> dict:
    """
    Compute β0(t) and β1(t): number of features alive at threshold t.
    """
    thresholds = np.linspace(0, 1, n_points)
    b0 = np.zeros(n_points)
    b1 = np.zeros(n_points)
    
    for i, t in enumerate(thresholds):
        b0[i] = sum(1 for (birth, death) in pairs_h0 if birth <= t <= death)
        b1[i] = sum(1 for (birth, death) in pairs_h1 if birth <= t <= death)
    
    return dict(thresholds=thresholds.tolist(), beta0=b0.tolist(), beta1=b1.tolist())


# ── Persistence landscape (vectorised) ────────────────────────────────────────

def persistence_landscape_vector(pairs: list,
                                  n_layers: int = 3,
                                  n_points: int = 50,
                                  t_min: float = 0.0,
                                  t_max: float = 1.0) -> np.ndarray:
    """
    Compute persistence landscape λ_k(t) for layers k=1..n_layers.
    Returns: array of shape (n_layers * n_points,)
    """
    thresholds = np.linspace(t_min, t_max, n_points)
    landscapes = np.zeros((n_layers, n_points))
    
    # For each t, sort the tent functions and take the k-th largest
    for i, t in enumerate(thresholds):
        tent_values = []
        for (b, d) in pairs:
            m = (b + d) / 2  # midpoint
            half = (d - b) / 2
            val = max(0, half - abs(t - m))
            if val > 0:
                tent_values.append(val)
        tent_values.sort(reverse=True)
        for k in range(n_layers):
            if k < len(tent_values):
                landscapes[k, i] = tent_values[k]
    
    return landscapes.flatten()


# ── Full feature vector ─────────────────────────────────────────────────────────

def extract_topological_feature_vector(image: np.ndarray,
                                        landscape_layers: int = 3,
                                        landscape_points: int = 30,
                                        ec_points: int = 30,
                                        betti_points: int = 30) -> np.ndarray:
    """
    Extract the full topological feature vector for one image.
    
    Feature breakdown:
    - H0 scalar statistics:  8
    - H1 scalar statistics:  8
    - H0 persistence landscape: landscape_layers * landscape_points
    - H1 persistence landscape: landscape_layers * landscape_points
    - Euler characteristic curve: ec_points
    - β0 curve: betti_points
    - β1 curve: betti_points
    Total (defaults): 8+8+90+90+30+30+30 = 286 features
    """
    result = compute_persistence_cubical(image)
    h0, h1 = result['h0'], result['h1']
    
    # Scalar statistics
    h0_stats = persistence_statistics(h0)
    h1_stats = persistence_statistics(h1)
    h0_vec = np.array(list(h0_stats.values()), dtype=np.float32)
    h1_vec = np.array(list(h1_stats.values()), dtype=np.float32)
    
    # Landscapes
    h0_land = persistence_landscape_vector(h0, landscape_layers, landscape_points)
    h1_land = persistence_landscape_vector(h1, landscape_layers, landscape_points)
    
    # Euler characteristic curve
    ec = euler_characteristic_curve(image, ec_points).astype(np.float32)
    # Normalise EC by number of pixels
    ec = ec / (image.shape[0] * image.shape[1])
    
    # Betti curves
    bc = betti_curve_from_pairs(h0, h1, betti_points)
    b0_vec = np.array(bc['beta0'], dtype=np.float32)
    b1_vec = np.array(bc['beta1'], dtype=np.float32)
    # Normalise
    if b0_vec.max() > 0: b0_vec /= b0_vec.max()
    if b1_vec.max() > 0: b1_vec /= b1_vec.max()
    
    feature_vector = np.concatenate([
        h0_vec, h1_vec,
        h0_land.astype(np.float32),
        h1_land.astype(np.float32),
        ec, b0_vec, b1_vec
    ])
    
    return feature_vector


def extract_features_batch(images: np.ndarray, verbose: bool = True) -> np.ndarray:
    """
    Extract topological features for a batch of images.
    images: (N, H, W) float32 array
    Returns: (N, D) feature matrix
    """
    features = []
    for i, img in enumerate(images):
        if verbose and i % 20 == 0:
            print(f"  Extracting features: {i}/{len(images)}")
        fv = extract_topological_feature_vector(img)
        features.append(fv)
    return np.array(features, dtype=np.float32)


if __name__ == "__main__":
    # Quick smoke test
    import sys
    sys.path.insert(0, '/home/claude/tqim_research')
    from preprocessing import get_ds1_classes, build_dataset
    import zipfile
    
    names, zf = get_ds1_classes('Training')
    X, y, classes = build_dataset(zf, names, target_size=64, max_per_class=5)
    print(f"Input: {X.shape}")
    
    fv = extract_topological_feature_vector(X[0])
    print(f"Feature vector length: {len(fv)}")
    print(f"Feature range: [{fv.min():.4f}, {fv.max():.4f}]")
    print(f"Feature breakdown:")
    print(f"  H0 stats: 8")
    print(f"  H1 stats: 8")
    print(f"  H0 landscape (3x30): 90")
    print(f"  H1 landscape (3x30): 90")
    print(f"  EC curve (30): 30")
    print(f"  Betti0 curve (30): 30")
    print(f"  Betti1 curve (30): 30")
    print(f"  Total: 286")
