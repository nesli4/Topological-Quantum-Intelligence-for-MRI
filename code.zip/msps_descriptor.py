"""
msps_descriptor.py
Multiscale Spatial Persistence Signature (MSPS)

MATHEMATICAL DEFINITION
=======================

Let I: Ω → [0,1] be a 2D grayscale MRI image on domain Ω ⊂ ℤ².

DUAL FILTRATION:
  Sub(t)   = {x ∈ Ω : I(x) ≤ t}   (sublevel sets — dark regions)
  Sup(t)   = {x ∈ Ω : I(x) ≥ 1-t}  (superlevel sets — bright regions)

For each filtration direction d ∈ {sub, sup} and homology dimension k ∈ {0,1},
let PD_k^d(I) = {(b_i^{d,k}, δ_i^{d,k})} be the persistence diagram,
where ℓ_i^{d,k} = δ_i^{d,k} - b_i^{d,k} is the lifetime (persistence).

SCALE-SPACE DECOMPOSITION:
  Gaussian blur at scale σ: I_σ = G_σ * I
  Scales: σ ∈ {0, 0.5, 1.0, 2.0} → resolutions {128, 64, 32, 16}

SCALE-NORMALISED ENTROPY:
  E_k^{d,σ}(I) = -∑_i p_i^{d,k,σ} · log(p_i^{d,k,σ})
  where p_i^{d,k,σ} = ℓ_i / ∑_j ℓ_j (over finite pairs)
  Normalised: Ẽ_k^{d,σ} = E_k^{d,σ} / log(n_k^{d,σ} + 1)
  (division by log(n+1) removes the trivial scale-dependence of count)

CROSS-SCALE ENTROPY SLOPE (novel contribution):
  For each direction d and dimension k, define:
  Γ_k^d(I) = slope of linear regression of Ẽ_k^{d,σ} on log(1/σ+1)
  
  Γ captures HOW FAST topological complexity grows with resolution.
  High Γ → topology emerges rapidly as we zoom in (rich fine-scale structure).
  Low Γ → topology is dominated by coarse structure (large connected regions).

LOCAL-GLOBAL TOPOLOGICAL CONTRAST (novel contribution):
  Partition image into P×P non-overlapping patches.
  For each patch p, compute Ẽ_1^{sub}(patch_p).
  Define:
    μ_patch = mean of local entropies over patches
    σ_patch = std  of local entropies over patches
    Λ(I) = σ_patch / (Ẽ_1^{sub,global}(I) + ε)
  
  Λ measures whether H1 complexity is CONCENTRATED (high spatial heterogeneity)
  or DIFFUSE (uniform). Tumors may show concentrated H1 complexity near mass.

MSPS VECTOR:
  For each (d, k, σ): [Ẽ, mean_persistence, max_persistence, n_pairs_normalised]
  = 4 × (2 directions × 2 dims × 4 scales) = 64 features
  Plus: [Γ_0^sub, Γ_1^sub, Γ_0^sup, Γ_1^sup] = 4 cross-scale slopes
  Plus: [Λ(I), μ_patch, σ_patch] = 3 local-global contrast features
  Total: 64 + 4 + 3 = 71 features

This is distinct from naive concatenation because:
  (a) Dual filtration captures both dark-to-bright AND bright-to-dark topology
  (b) Scale normalisation removes trivial resolution artefacts
  (c) Cross-scale slope is a new derived quantity not computable from any
      single-scale persistence diagram
  (d) Local-global contrast is a spatial statistic that single-scale global
      persistence cannot encode
"""

import numpy as np
import gudhi
from scipy.ndimage import gaussian_filter
from scipy.stats import linregress
import warnings
warnings.filterwarnings('ignore')


# ── Configuration ──────────────────────────────────────────────────────────────

SCALES_SIGMA = [0.0, 0.5, 1.0, 2.0]   # Gaussian blur sigmas
TARGET_SIZES = [128, 64, 32, 16]        # corresponding resolutions
PATCH_GRID   = 4                         # 4×4 = 16 patches for local analysis
EPS          = 1e-9


# ── Core: persistence for one image at one scale/filtration ───────────────────

def _persistence_one(arr: np.ndarray, sublevel: bool = True) -> dict:
    """
    Compute cubical persistent homology on arr.
    sublevel=True  → standard (dark regions first)
    sublevel=False → superlevel (bright regions first, implemented via inversion)
    
    Returns dict with h0, h1 (finite pairs only) and betti numbers.
    """
    H, W = arr.shape
    cells = arr.flatten() if sublevel else (1.0 - arr).flatten()
    
    cc = gudhi.CubicalComplex(dimensions=[H, W],
                               top_dimensional_cells=cells)
    cc.compute_persistence()
    pairs = cc.persistence()
    
    h0 = [(b, d) for (dim, (b, d)) in pairs if dim == 0 and d != float('inf')]
    h1 = [(b, d) for (dim, (b, d)) in pairs if dim == 1 and d != float('inf')]
    
    return {'h0': h0, 'h1': h1}


def _normalised_stats(pairs: list, image_area: int) -> dict:
    """
    Compute scale-normalised persistence statistics.
    n_pairs_norm = n / (H*W) removes size dependence.
    entropy_norm = H / log(n+1) removes count dependence.
    """
    n = len(pairs)
    if n == 0:
        return dict(entropy_norm=0.0, mean_pers=0.0, max_pers=0.0,
                    n_norm=0.0, sum_pers=0.0)
    
    lifetimes = np.array([d - b for b, d in pairs])
    total = lifetimes.sum()
    
    if total > 0:
        p = lifetimes / total
        entropy = float(-np.sum(p * np.log(p + EPS)))
    else:
        entropy = 0.0
    
    entropy_norm = entropy / (np.log(n + 1) + EPS)   # remove count effect
    n_norm       = n / (image_area + EPS)              # remove area effect
    
    return dict(
        entropy_norm  = entropy_norm,
        mean_pers     = float(lifetimes.mean()),
        max_pers      = float(lifetimes.max()),
        n_norm        = n_norm,
        sum_pers      = float(total / (image_area + EPS)),  # density
    )


# ── Cross-scale entropy slope ──────────────────────────────────────────────────

def _cross_scale_slope(entropy_at_scales: list, log_scales: list) -> float:
    """
    Linear regression slope of entropy vs log-scale.
    Returns 0.0 if fewer than 2 valid points.
    """
    valid = [(l, e) for l, e in zip(log_scales, entropy_at_scales)
             if np.isfinite(e) and np.isfinite(l)]
    if len(valid) < 2:
        return 0.0
    ls, es = zip(*valid)
    slope, _, _, _, _ = linregress(ls, es)
    return float(slope)


# ── Local-global contrast ──────────────────────────────────────────────────────

def _local_global_contrast(image: np.ndarray, P: int = PATCH_GRID) -> dict:
    """
    Compute H1 entropy in P×P patches vs global H1 entropy.
    Returns Λ, μ_patch, σ_patch.
    """
    H, W = image.shape
    ph, pw = H // P, W // P
    
    local_entropies = []
    for i in range(P):
        for j in range(P):
            patch = image[i*ph:(i+1)*ph, j*pw:(j+1)*pw]
            if patch.size < 4:
                continue
            result = _persistence_one(patch, sublevel=True)
            stats = _normalised_stats(result['h1'], patch.size)
            local_entropies.append(stats['entropy_norm'])
    
    # Global H1 entropy
    global_result = _persistence_one(image, sublevel=True)
    global_stats  = _normalised_stats(global_result['h1'], image.size)
    global_entropy = global_stats['entropy_norm']
    
    local_arr = np.array(local_entropies) if local_entropies else np.array([0.0])
    mu_patch  = float(local_arr.mean())
    sig_patch = float(local_arr.std())
    Lambda    = sig_patch / (global_entropy + EPS)
    
    return dict(Lambda=Lambda, mu_patch=mu_patch, sigma_patch=sig_patch,
                global_entropy=global_entropy)


# ── Full MSPS extraction ───────────────────────────────────────────────────────

def extract_msps(image: np.ndarray) -> np.ndarray:
    """
    Extract the full 71-dimensional MSPS vector from a [0,1] grayscale image.
    
    image: (H, W) float32/64 array in [0,1]
    Returns: (71,) float32 vector
    
    Feature layout:
      [0:64]   — 4 stats × 2 dirs × 2 dims × 4 scales  (scale-indexed)
      [64:68]  — 4 cross-scale slopes (Γ)
      [68:71]  — 3 local-global contrast features (Λ, μ, σ)
    """
    H, W = image.shape
    
    # ── Build blurred versions at each scale ──
    blurred = []
    for sigma in SCALES_SIGMA:
        if sigma == 0.0:
            blurred.append(image.copy())
        else:
            blurred.append(np.clip(gaussian_filter(image, sigma=sigma), 0, 1))
    
    # ── Collect per-scale/direction/dimension stats ──
    # Layout: stats_grid[direction][dim][scale] = dict
    dirs   = ['sub', 'sup']
    dims   = [0, 1]        # H0, H1
    
    entropy_grid = {}   # (dir, dim) → list of entropies per scale
    feature_parts = []
    
    for d_idx, sublevel in enumerate([True, False]):
        for k in dims:
            key = (d_idx, k)
            entropy_grid[key] = []
            for s_idx, arr in enumerate(blurred):
                # Down-sample to target size for speed
                ts = TARGET_SIZES[s_idx]
                if arr.shape[0] != ts or arr.shape[1] != ts:
                    from PIL import Image as PILImg
                    pil = PILImg.fromarray((arr * 255).astype(np.uint8))
                    arr_rs = np.array(pil.resize((ts, ts), PILImg.LANCZOS),
                                      dtype=np.float64) / 255.0
                else:
                    arr_rs = arr.astype(np.float64)
                
                result = _persistence_one(arr_rs, sublevel=sublevel)
                pairs  = result[f'h{k}']
                stats  = _normalised_stats(pairs, ts * ts)
                
                # 4 features per (dir, dim, scale)
                feature_parts.extend([
                    stats['entropy_norm'],
                    stats['mean_pers'],
                    stats['max_pers'],
                    stats['n_norm'],
                ])
                entropy_grid[key].append(stats['entropy_norm'])
    
    # ── Cross-scale slopes ──
    # log-scale values: log(1/(sigma+1)+1) — monotone, well-defined
    log_scales = [np.log(1.0 / (s + 1) + 1) for s in SCALES_SIGMA]
    slopes = []
    for d_idx in range(2):
        for k in dims:
            slope = _cross_scale_slope(entropy_grid[(d_idx, k)], log_scales)
            slopes.append(slope)
    
    # ── Local-global contrast ──
    # Use finest scale (original image, downsampled to 64)
    from PIL import Image as PILImg
    img64 = np.array(
        PILImg.fromarray((image * 255).astype(np.uint8)).resize((64, 64),
                          PILImg.LANCZOS), dtype=np.float64) / 255.0
    lgc = _local_global_contrast(img64, P=PATCH_GRID)
    
    contrast_features = [lgc['Lambda'], lgc['mu_patch'], lgc['sigma_patch']]
    
    # ── Assemble ──
    msps = np.array(feature_parts + slopes + contrast_features, dtype=np.float32)
    assert len(msps) == 71, f"Expected 71, got {len(msps)}"
    return msps


def extract_msps_batch(images: np.ndarray, verbose: bool = True) -> np.ndarray:
    """
    Extract MSPS for a batch of images.
    images: (N, H, W) float32
    Returns: (N, 71) float32
    """
    features = []
    for i, img in enumerate(images):
        if verbose and i % 10 == 0:
            print(f"  MSPS extraction: {i}/{len(images)}")
        features.append(extract_msps(img))
    return np.array(features, dtype=np.float32)


def msps_feature_names() -> list:
    """Return human-readable names for all 71 MSPS features."""
    names = []
    dir_names = ['sub', 'sup']
    dim_names = ['H0', 'H1']
    stat_names = ['entropy_norm', 'mean_pers', 'max_pers', 'n_norm']
    scale_names = ['σ=0', 'σ=0.5', 'σ=1', 'σ=2']
    
    for d in dir_names:
        for k in dim_names:
            for s in scale_names:
                for st in stat_names:
                    names.append(f'{d}.{k}.{s}.{st}')
    
    for d in dir_names:
        for k in dim_names:
            names.append(f'slope.{d}.{k}')
    
    names += ['Lambda', 'mu_patch', 'sigma_patch']
    
    assert len(names) == 71
    return names


# ── Smoke test ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import io, zipfile, random
    
    z = zipfile.ZipFile('/mnt/user-data/uploads/brain-tumor-mri-dataset.zip')
    names = [n for n in z.namelist() if n.endswith('.jpg') and 'Training' in n]
    random.seed(42)
    
    classes = ['glioma','meningioma','notumor','pituitary']
    sample_per_class = {}
    for cls in classes:
        cls_imgs = [n for n in names if f'/{cls}/' in n]
        sample_per_class[cls] = random.choice(cls_imgs)
    
    print('=== MSPS Smoke Test ===')
    for cls, path in sample_per_class.items():
        raw = z.read(path)
        from PIL import Image as PILImg
        img = np.array(PILImg.open(io.BytesIO(raw)).convert('L'),
                        dtype=np.float32) / 255.0
        msps = extract_msps(img)
        print(f'\n{cls}:')
        print(f'  MSPS shape: {msps.shape}')
        print(f'  Range: [{msps.min():.4f}, {msps.max():.4f}]')
        
        # Print key features
        names_list = msps_feature_names()
        print(f'  Cross-scale slopes (Γ):')
        for i in range(64, 68):
            print(f'    {names_list[i]}: {msps[i]:.4f}')
        print(f'  Local-global contrast:')
        for i in range(68, 71):
            print(f'    {names_list[i]}: {msps[i]:.4f}')
    
    print(f'\nTotal features: {len(msps_feature_names())}')
    print('Feature names (first 8):', msps_feature_names()[:8])
